<?php
/**
 * Plugin Name: Prismtek Pixel Vibes
 * Description: Pixel-art indie styling + day/night weather scene + arcade/chat/pixel-wall hub.
 */

if (!defined('ABSPATH')) {
    exit;
}

function prismtek_pixel_client_ip() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    return preg_replace('/[^0-9a-fA-F:\.]/', '', (string) $ip);
}

function prismtek_pixel_get_chat_messages() {
    $rows = get_option('prismtek_pixel_chat_messages', []);
    return is_array($rows) ? $rows : [];
}

function prismtek_pixel_set_chat_messages($rows) {
    if (!is_array($rows)) $rows = [];
    update_option('prismtek_pixel_chat_messages', array_slice($rows, -160), false);
}

function prismtek_pixel_get_wall_items() {
    $rows = get_option('prismtek_pixel_wall_items', []);
    return is_array($rows) ? $rows : [];
}

function prismtek_pixel_set_wall_items($rows) {
    if (!is_array($rows)) $rows = [];
    update_option('prismtek_pixel_wall_items', array_slice($rows, -180), false);
}

function prismtek_pixel_get_scores() {
    $rows = get_option('prismtek_pixel_scores', []);
    return is_array($rows) ? $rows : [];
}

function prismtek_pixel_set_scores($rows) {
    if (!is_array($rows)) $rows = [];
    update_option('prismtek_pixel_scores', $rows, false);
}


function prismtek_pixel_get_game_meta() {
    $rows = get_option('prismtek_game_meta', []);
    return is_array($rows) ? $rows : [];
}

function prismtek_pixel_set_game_meta($rows) {
    if (!is_array($rows)) $rows = [];
    update_option('prismtek_game_meta', $rows, false);
}


function prismtek_pet_default_state() {
    return [
        'name' => 'Prismo',
        'species' => 'blob',
        'skin' => 'default',
        'createdTs' => time(),
        'hunger' => 75,
        'happiness' => 70,
        'energy' => 80,
        'health' => 85,
        'lastTs' => time(),
    ];
}

function prismtek_pet_apply_decay($state) {
    if (!is_array($state)) $state = prismtek_pet_default_state();
    $now = time();
    $last = (int)($state['lastTs'] ?? $now);
    $elapsed = max(0, $now - $last);
    $hours = $elapsed / 3600.0;

    $state['hunger'] = max(0, min(100, (int)round(($state['hunger'] ?? 75) - 6 * $hours)));
    $state['happiness'] = max(0, min(100, (int)round(($state['happiness'] ?? 70) - 4 * $hours)));
    $state['energy'] = max(0, min(100, (int)round(($state['energy'] ?? 80) - 5 * $hours)));

    $baseHealth = (int)($state['health'] ?? 85);
    $penalty = 0;
    if (($state['hunger'] ?? 0) < 25) $penalty += 4;
    if (($state['energy'] ?? 0) < 20) $penalty += 4;
    if (($state['happiness'] ?? 0) < 20) $penalty += 3;
    $state['health'] = max(0, min(100, (int)round($baseHealth - $penalty * $hours)));

    $state['lastTs'] = $now;
    return $state;
}

function prismtek_pet_get_state($uid) {
    $state = get_user_meta((int)$uid, 'prismtek_pet_state', true);
    if (!is_array($state) || empty($state)) $state = prismtek_pet_default_state();
    $state = prismtek_pet_apply_decay($state);
    update_user_meta((int)$uid, 'prismtek_pet_state', $state);
    return $state;
}

function prismtek_pet_set_state($uid, $state) {
    if (!is_array($state)) $state = prismtek_pet_default_state();
    if (empty($state['createdTs'])) $state['createdTs'] = time();
    $state['lastTs'] = time();
    update_user_meta((int)$uid, 'prismtek_pet_state', $state);
}

function prismtek_pet_compute_stage($state) {
    $created = (int)($state['createdTs'] ?? time());
    $days = max(0, floor((time() - $created) / 86400));
    $care = ((int)($state['hunger'] ?? 0) + (int)($state['happiness'] ?? 0) + (int)($state['energy'] ?? 0) + (int)($state['health'] ?? 0)) / 4;
    if ($days >= 7 && $care >= 70) return 'adult';
    if ($days >= 2 && $care >= 45) return 'teen';
    return 'baby';
}

function prismtek_pet_get_unlocks($uid) {
    $scores = prismtek_pixel_get_scores();
    $max = 0;
    foreach ($scores as $game => $rows) {
        if (!is_array($rows)) continue;
        foreach ($rows as $r) {
            if ((int)($r['userId'] ?? 0) === (int)$uid) {
                $max = max($max, (int)($r['score'] ?? 0));
            }
        }
    }
    $skins = ['default'];
    if ($max >= 50) $skins[] = 'mint';
    if ($max >= 150) $skins[] = 'sunset';
    if ($max >= 300) $skins[] = 'galaxy';
    if ($max >= 600) $skins[] = 'neon';
    return ['maxScore' => $max, 'skins' => $skins];
}

add_action('rest_api_init', function () {
    register_rest_route('prismtek/v1', '/session', [
        'methods' => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function () {
            nocache_headers();
            $uid = get_current_user_id();
            return rest_ensure_response([
                'ok' => true,
                'loggedIn' => (bool) $uid,
                'canModerate' => current_user_can('manage_options'),
                'nonce' => $uid ? wp_create_nonce('wp_rest') : '',
                'user' => $uid ? wp_get_current_user()->display_name : '',
                'userId' => $uid ? (int)$uid : 0,
            ]);
        },
    ]);

    register_rest_route('prismtek/v1', '/chat', [
        'methods' => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function () {
            return rest_ensure_response([
                'ok' => true,
                'messages' => array_slice(prismtek_pixel_get_chat_messages(), -80),
            ]);
        },
    ]);

    register_rest_route('prismtek/v1', '/chat', [
        'methods' => 'POST',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $ip = prismtek_pixel_client_ip();
            $key = 'prismtek_chat_rate_' . md5($ip);
            if (get_transient($key)) {
                return new WP_REST_Response(['ok' => false, 'error' => 'rate_limited'], 429);
            }
            set_transient($key, '1', 2);

            $name = sanitize_text_field((string) $request->get_param('name'));
            $text = sanitize_textarea_field((string) $request->get_param('message'));
            $age13 = (bool) $request->get_param('age13');
            if (!$age13) return new WP_REST_Response(['ok' => false, 'error' => 'age_consent_required'], 400);
            $name = trim($name ?: 'Community Member');
            $text = trim($text);
            if ($text === '') return new WP_REST_Response(['ok' => false, 'error' => 'missing_message'], 400);

            $row = [
                'id' => wp_generate_uuid4(),
                'name' => mb_substr($name, 0, 24),
                'message' => mb_substr($text, 0, 280),
                'replyTo' => sanitize_text_field((string)$request->get_param('replyTo')),
                'reactions' => [],
                'userId' => get_current_user_id() ? (int)get_current_user_id() : 0,
                'ts' => time(),
            ];

            $rows = prismtek_pixel_get_chat_messages();
            $rows[] = $row;
            prismtek_pixel_set_chat_messages($rows);

            return rest_ensure_response(['ok' => true, 'message' => $row]);
        },
    ]);

    register_rest_route('prismtek/v1', '/pixel-wall', [
        'methods' => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function () {
            return rest_ensure_response([
                'ok' => true,
                'items' => array_reverse(array_slice(prismtek_pixel_get_wall_items(), -120)),
            ]);
        },
    ]);

    register_rest_route('prismtek/v1', '/chat/react', [
        'methods' => 'POST',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $id = sanitize_text_field((string)$request->get_param('id'));
            $key = sanitize_key((string)$request->get_param('emoji'));
            $allowed = ['up','heart','fire'];
            if ($id === '' || !in_array($key, $allowed, true)) return new WP_REST_Response(['ok'=>false,'error'=>'invalid_payload'],400);
            $uid = get_current_user_id();
            $reactor = $uid ? ('u:' . (int)$uid) : ('i:' . substr(md5(prismtek_pixel_client_ip()), 0, 16));

            $rows = prismtek_pixel_get_chat_messages();
            foreach ($rows as &$r) {
                if (($r['id'] ?? '') !== $id) continue;

                $re = is_array($r['reactions'] ?? null) ? $r['reactions'] : [];
                $ru = is_array($r['reactionUsers'] ?? null) ? $r['reactionUsers'] : [];
                $users = is_array($ru[$key] ?? null) ? $ru[$key] : [];

                if (in_array($reactor, $users, true)) {
                    return rest_ensure_response(['ok'=>true,'duplicate'=>true,'reactions'=>$re]);
                }

                $users[] = $reactor;
                $ru[$key] = $users;
                $re[$key] = count($users);

                $r['reactionUsers'] = $ru;
                $r['reactions'] = $re;
                prismtek_pixel_set_chat_messages($rows);
                return rest_ensure_response(['ok'=>true,'reactions'=>$re]);
            }
            unset($r);
            return new WP_REST_Response(['ok'=>false,'error'=>'not_found'],404);
        },
    ]);

    register_rest_route('prismtek/v1', '/chat/(?P<id>[a-zA-Z0-9\-]+)', [
        'methods' => 'DELETE',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $id = sanitize_text_field((string)$request['id']);
            $uid = get_current_user_id();
            if (!$uid) return new WP_REST_Response(['ok'=>false,'error'=>'auth_required'],401);

            $rows = prismtek_pixel_get_chat_messages();
            $next = [];
            $found = null;
            foreach ($rows as $r) {
                if (($r['id'] ?? '') === $id) { $found = $r; continue; }
                $next[] = $r;
            }
            if (!$found) return new WP_REST_Response(['ok'=>false,'error'=>'not_found'],404);

            $owner = (int)($found['userId'] ?? 0);
            $is_admin = current_user_can('manage_options');
            $is_owner = ($owner > 0 && $owner === (int)$uid);
            if (!$is_admin && !$is_owner) return new WP_REST_Response(['ok'=>false,'error'=>'forbidden'],403);

            prismtek_pixel_set_chat_messages($next);
            return rest_ensure_response(['ok'=>true]);
        },
    ]);


    register_rest_route('prismtek/v1', '/pixel-wall', [
        'methods' => 'POST',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $ip = prismtek_pixel_client_ip();
            $key = 'prismtek_wall_rate_' . md5($ip);
            if (get_transient($key)) {
                return new WP_REST_Response(['ok' => false, 'error' => 'rate_limited'], 429);
            }
            set_transient($key, '1', 6);

            if (empty($_FILES['image'])) {
                return new WP_REST_Response(['ok' => false, 'error' => 'missing_file'], 400);
            }

            $name = sanitize_text_field((string) $request->get_param('name'));
            $caption = sanitize_text_field((string) $request->get_param('caption'));
            $age13 = (bool) $request->get_param('age13');
            if (!$age13) return new WP_REST_Response(['ok' => false, 'error' => 'age_consent_required'], 400);
            $name = trim($name ?: 'Community Member');
            $caption = trim($caption);

            $file = $_FILES['image'];
            if (!empty($file['size']) && (int)$file['size'] > 3 * 1024 * 1024) {
                return new WP_REST_Response(['ok' => false, 'error' => 'file_too_large'], 400);
            }

            require_once ABSPATH . 'wp-admin/includes/file.php';
            $overrides = [
                'test_form' => false,
                'mimes' => [
                    'png' => 'image/png',
                    'jpg|jpeg' => 'image/jpeg',
                    'webp' => 'image/webp',
                    'gif' => 'image/gif',
                ],
            ];

            $uploaded = wp_handle_upload($file, $overrides);
            if (!empty($uploaded['error'])) {
                return new WP_REST_Response(['ok' => false, 'error' => 'upload_failed', 'detail' => $uploaded['error']], 400);
            }

            $uid = get_current_user_id();
            $row = [
                'id' => wp_generate_uuid4(),
                'name' => mb_substr($name, 0, 24),
                'caption' => mb_substr($caption, 0, 120),
                'url' => esc_url_raw((string) ($uploaded['url'] ?? '')),
                'tags' => array_values(array_filter(array_map('sanitize_title', explode(',', (string)$request->get_param('tags'))))),
                'featured' => false,
                'ts' => time(),
                'userId' => $uid ? (int)$uid : 0,
            ];

            $rows = prismtek_pixel_get_wall_items();
            $rows[] = $row;
            prismtek_pixel_set_wall_items($rows);

            return rest_ensure_response(['ok' => true, 'item' => $row]);
        },
    ]);

    register_rest_route('prismtek/v1', '/pixel-wall/(?P<id>[a-zA-Z0-9\-]+)', [
        'methods' => 'DELETE',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $id = sanitize_text_field((string) $request['id']);
            $uid = get_current_user_id();
            if (!$uid) return new WP_REST_Response(['ok' => false, 'error' => 'auth_required'], 401);

            $rows = prismtek_pixel_get_wall_items();
            $found = null;
            $next = [];
            foreach ($rows as $row) {
                if (($row['id'] ?? '') === $id) { $found = $row; continue; }
                $next[] = $row;
            }
            if (!$found) return new WP_REST_Response(['ok' => false, 'error' => 'not_found'], 404);

            $owner = (int) ($found['userId'] ?? 0);
            $is_admin = current_user_can('manage_options');
            $is_owner = ($owner > 0 && $owner === (int)$uid);
            if (!$is_admin && !$is_owner) return new WP_REST_Response(['ok' => false, 'error' => 'forbidden'], 403);

            $url = (string) ($found['url'] ?? '');
            if ($url) {
                $up = wp_get_upload_dir();
                $base = rtrim((string)($up['baseurl'] ?? ''), '/');
                if ($base && str_starts_with($url, $base . '/')) {
                    $rel = ltrim(substr($url, strlen($base)), '/');
                    $path = trailingslashit((string)($up['basedir'] ?? '')) . $rel;
                    if (is_file($path)) @unlink($path);
                }
            }

            prismtek_pixel_set_wall_items($next);
            return rest_ensure_response(['ok' => true]);
        },
    ]);


    register_rest_route('prismtek/v1', '/pixel-wall/feature', [
        'methods' => 'POST',
        'permission_callback' => function () { return current_user_can('manage_options'); },
        'callback' => function (WP_REST_Request $request) {
            $id = sanitize_text_field((string)$request->get_param('id'));
            $featured = (bool)$request->get_param('featured');
            $rows = prismtek_pixel_get_wall_items();
            foreach ($rows as &$r) {
                if (($r['id'] ?? '') !== $id) continue;
                $r['featured'] = $featured;
                prismtek_pixel_set_wall_items($rows);
                return rest_ensure_response(['ok'=>true]);
            }
            unset($r);
            return new WP_REST_Response(['ok'=>false,'error'=>'not_found'],404);
        },
    ]);

    register_rest_route('prismtek/v1', '/games', [
        'methods' => 'POST',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'callback' => function (WP_REST_Request $request) {
            if (empty($_FILES['gameZip'])) {
                return new WP_REST_Response(['ok' => false, 'error' => 'missing_file'], 400);
            }

            $title = sanitize_text_field((string) $request->get_param('title'));
            $title = trim($title ?: pathinfo((string)($_FILES['gameZip']['name'] ?? 'game'), PATHINFO_FILENAME));
            $slug = sanitize_title($title ?: 'game-' . wp_generate_password(6, false, false));

            $baseDir = WP_CONTENT_DIR . '/uploads/pixel-games';
            if (!is_dir($baseDir)) wp_mkdir_p($baseDir);
            $targetDir = $baseDir . '/' . $slug;
            if (is_dir($targetDir)) {
                $it = new RecursiveDirectoryIterator($targetDir, RecursiveDirectoryIterator::SKIP_DOTS);
                $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
                foreach ($files as $file) {
                    $file->isDir() ? @rmdir($file->getRealPath()) : @unlink($file->getRealPath());
                }
                @rmdir($targetDir);
            }
            wp_mkdir_p($targetDir);

            $tmp = (string) ($_FILES['gameZip']['tmp_name'] ?? '');
            $name = strtolower((string) ($_FILES['gameZip']['name'] ?? ''));
            if (!$tmp || !is_uploaded_file($tmp)) {
                return new WP_REST_Response(['ok' => false, 'error' => 'upload_failed'], 400);
            }

            if (str_ends_with($name, '.zip')) {
                if (!class_exists('ZipArchive')) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'zip_not_supported'], 500);
                }
                $zip = new ZipArchive();
                if ($zip->open($tmp) !== true) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'invalid_zip'], 400);
                }
                $zip->extractTo($targetDir);
                $zip->close();
            } elseif (str_ends_with($name, '.html') || str_ends_with($name, '.htm')) {
                $dest = $targetDir . '/index.html';
                if (!move_uploaded_file($tmp, $dest)) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'move_failed'], 400);
                }
            } else {
                return new WP_REST_Response(['ok' => false, 'error' => 'unsupported_file'], 400);
            }

            // Normalize common nested zip layout: single top folder
            $entries = array_values(array_filter(glob($targetDir . '/*') ?: [], fn($x) => basename($x) !== '__MACOSX'));
            if (count($entries) === 1 && is_dir($entries[0])) {
                $inner = $entries[0];
                foreach (glob($inner . '/*') ?: [] as $child) {
                    @rename($child, $targetDir . '/' . basename($child));
                }
                @rmdir($inner);
            }

            $htmlCandidates = glob($targetDir . '/index.html') ?: glob($targetDir . '/*.html');
            if (empty($htmlCandidates)) {
                return new WP_REST_Response(['ok' => false, 'error' => 'no_html_found'], 400);
            }

            $entryPath = $htmlCandidates[0];
            $entryFile = basename($entryPath);
            $url = content_url('uploads/pixel-games/' . rawurlencode($slug) . '/' . rawurlencode($entryFile));
            $html = @file_get_contents($entryPath) ?: '';
            $checks = [
                ['name' => 'viewport-meta', 'ok' => (stripos($html, 'viewport') !== false)],
                ['name' => 'script-present', 'ok' => (stripos($html, '<script') !== false)],
                ['name' => 'mobile-input', 'ok' => (stripos($html, 'pointer') !== false || stripos($html, 'touch') !== false)],
                ['name' => 'score-hook', 'ok' => (stripos($html, '/scores') !== false)],
            ];
            return rest_ensure_response(['ok' => true, 'slug' => $slug, 'url' => $url, 'checks' => $checks]);
        },
    ]);


    

    register_rest_route('prismtek/v1', '/register', [
        'methods' => 'POST',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $ip = prismtek_pixel_client_ip();
            $key = 'prismtek_register_rate_' . md5($ip);
            if (get_transient($key)) {
                return new WP_REST_Response(['ok' => false, 'error' => 'rate_limited'], 429);
            }
            set_transient($key, '1', 20);

            $username = sanitize_user((string) $request->get_param('username'), true);
            $email = sanitize_email((string) $request->get_param('email'));
            $password = (string) $request->get_param('password');
            $age13 = (bool) $request->get_param('age13');

            if (!$age13) return new WP_REST_Response(['ok' => false, 'error' => 'age_consent_required'], 400);
            if ($username === '' || strlen($username) < 3) return new WP_REST_Response(['ok' => false, 'error' => 'invalid_username'], 400);
            if (!is_email($email)) return new WP_REST_Response(['ok' => false, 'error' => 'invalid_email'], 400);
            if (strlen($password) < 8) return new WP_REST_Response(['ok' => false, 'error' => 'weak_password'], 400);
            if (username_exists($username)) return new WP_REST_Response(['ok' => false, 'error' => 'username_taken'], 409);
            if (email_exists($email)) return new WP_REST_Response(['ok' => false, 'error' => 'email_taken'], 409);

            $uid = wp_create_user($username, $password, $email);
            if (is_wp_error($uid)) {
                return new WP_REST_Response(['ok' => false, 'error' => 'create_failed', 'detail' => $uid->get_error_message()], 400);
            }

            wp_update_user([
                'ID' => (int)$uid,
                'display_name' => $username,
                'nickname' => $username,
            ]);

            wp_set_current_user((int)$uid);
            wp_set_auth_cookie((int)$uid, true, is_ssl());

            return rest_ensure_response(['ok' => true, 'userId' => (int)$uid, 'username' => $username]);
        },
    ]);

    register_rest_route('prismtek/v1', '/games/meta', [
        'methods' => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $slug = sanitize_title((string)$request->get_param('slug'));
            $all = prismtek_pixel_get_game_meta();
            return rest_ensure_response(['ok'=>true, 'meta' => is_array($all[$slug] ?? null) ? $all[$slug] : []]);
        },
    ]);

    register_rest_route('prismtek/v1', '/games/meta', [
        'methods' => 'POST',
        'permission_callback' => function () { return current_user_can('manage_options'); },
        'callback' => function (WP_REST_Request $request) {
            $slug = sanitize_title((string)$request->get_param('slug'));
            if ($slug === '') return new WP_REST_Response(['ok'=>false,'error'=>'missing_slug'],400);
            $all = prismtek_pixel_get_game_meta();
            $all[$slug] = [
                'category' => sanitize_text_field((string)$request->get_param('category')),
                'difficulty' => sanitize_text_field((string)$request->get_param('difficulty')),
                'controls' => sanitize_text_field((string)$request->get_param('controls')),
                'description' => sanitize_text_field((string)$request->get_param('description')),
            ];
            prismtek_pixel_set_game_meta($all);
            return rest_ensure_response(['ok'=>true]);
        },
    ]);

    register_rest_route('prismtek/v1', '/scores', [
        'methods' => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $game = sanitize_title((string) $request->get_param('game'));
            if ($game === '') return new WP_REST_Response(['ok' => false, 'error' => 'missing_game'], 400);
            $all = prismtek_pixel_get_scores();
            $rows = is_array($all[$game] ?? null) ? $all[$game] : [];
            usort($rows, function ($a, $b) {
                return ((int)($b['score'] ?? 0)) <=> ((int)($a['score'] ?? 0));
            });
            $dedup = [];
            $seen = [];
            foreach ($rows as $row) {
                $uid = (int)($row['userId'] ?? 0);
                $name = strtolower((string)($row['name'] ?? 'guest'));
                $k = $uid > 0 ? ('u:' . $uid) : ('n:' . $name);
                if (isset($seen[$k])) continue;
                $seen[$k] = true;
                $dedup[] = $row;
            }
            $top = array_slice($dedup, 0, 3);
            foreach ($top as &$row) {
                $ruid = (int)($row['userId'] ?? 0);
                $nm = (string)($row['name'] ?? 'Guest');
                $row['initial'] = strtoupper(mb_substr($nm, 0, 1));
                $row['avatar'] = $ruid > 0 ? get_avatar_url($ruid, ['size' => 48, 'default' => 'identicon']) : '';
            }
            unset($row);
            return rest_ensure_response(['ok' => true, 'game' => $game, 'top' => $top]);
        },
    ]);



    register_rest_route('prismtek/v1', '/scores/reset', [
        'methods' => 'POST',
        'permission_callback' => function () { return current_user_can('manage_options'); },
        'callback' => function (WP_REST_Request $request) {
            $game = sanitize_title((string)$request->get_param('game'));
            $all = prismtek_pixel_get_scores();
            if ($game !== '') {
                $all[$game] = [];
            } else {
                $all = [];
            }
            prismtek_pixel_set_scores($all);
            return rest_ensure_response(['ok' => true]);
        },
    ]);

    register_rest_route('prismtek/v1', '/scores', [
        'methods' => 'POST',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $game = sanitize_title((string) $request->get_param('game'));
            $score = (int) $request->get_param('score');
            if ($game === '' || $score <= 0) return new WP_REST_Response(['ok' => false, 'error' => 'invalid_payload'], 400);
            if ($score > 1000000) return new WP_REST_Response(['ok' => false, 'error' => 'score_too_high'], 400);
            $ip = prismtek_pixel_client_ip();
            $rk = 'prismtek_score_rate_' . md5($ip);
            if (get_transient($rk)) return new WP_REST_Response(['ok' => false, 'error' => 'rate_limited'], 429);
            set_transient($rk, '1', 1);

            $uid = get_current_user_id();
            $name = sanitize_text_field((string) $request->get_param('name'));
            $playerKey = sanitize_text_field((string) $request->get_param('playerKey'));
            $playerKey = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$playerKey);
            if ($uid) {
                $u = wp_get_current_user();
                $disp = trim((string) ($u->display_name ?? ''));
                $login = (string) ($u->user_login ?? '');
                $name = $disp !== '' ? $disp : $login;
            }
            $name = trim($name ?: 'Guest');

            $all = prismtek_pixel_get_scores();
            $rows = is_array($all[$game] ?? null) ? $all[$game] : [];

            $updated = false;
            foreach ($rows as &$r) {
                $sameUser = ($uid && (int)($r['userId'] ?? 0) === (int)$uid);
                $sameKey = (!$uid && $playerKey !== '' && (string)($r['playerKey'] ?? '') === $playerKey);
                $sameNameGuest = (!$uid && (string)($r['name'] ?? '') === $name && ((string)($r['playerKey'] ?? '') === '' || $playerKey === ''));
                if ($sameUser || $sameKey || $sameNameGuest) {
                    $prev = (int)($r['score'] ?? 0);
                    if ($score > $prev + 5000) return new WP_REST_Response(['ok' => false, 'error' => 'suspicious_delta'], 400);
                    if ($score > $prev) {
                        $r['score'] = $score;
                    }
                    $r['ts'] = time();
                    if ($uid) $r['userId'] = (int)$uid;
                    if ($playerKey !== '') $r['playerKey'] = $playerKey;
                    $r['name'] = mb_substr($name, 0, 24);
                    $updated = true;
                    break;
                }
            }
            unset($r);

            if (!$updated) {
                $rows[] = [
                    'name' => mb_substr($name, 0, 24),
                    'score' => $score,
                    'userId' => $uid ? (int)$uid : 0,
                    'playerKey' => $playerKey,
                    'ts' => time(),
                ];
            }

            usort($rows, function ($a, $b) {
                return ((int)($b['score'] ?? 0)) <=> ((int)($a['score'] ?? 0));
            });

            // Deduplicate by identity (userId > playerKey > name)
            $dedup = [];
            $seen = [];
            foreach ($rows as $row) {
                $k = '';
                $ru = (int)($row['userId'] ?? 0);
                $rn = (string)($row['name'] ?? 'Guest');
                if ($ru > 0) $k = 'u:' . $ru;
                else $k = 'n:' . strtolower($rn);
                if (isset($seen[$k])) continue;
                $seen[$k] = true;
                $dedup[] = $row;
            }

            $all[$game] = array_slice($dedup, 0, 50);
            prismtek_pixel_set_scores($all);

            return rest_ensure_response(['ok' => true, 'top' => array_slice($all[$game], 0, 3)]);
        },
    ]);


    register_rest_route('prismtek/v1', '/profile', [
        'methods' => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function () {
            $uid = get_current_user_id();
            if (!$uid) return new WP_REST_Response(['ok' => false, 'error' => 'auth_required'], 401);
            $u = wp_get_current_user();
            return rest_ensure_response([
                'ok' => true,
                'displayName' => (string)($u->display_name ?? ''),
                'bio' => (string)get_user_meta($uid, 'prismtek_bio', true),
                'favoriteGame' => (string)get_user_meta($uid, 'prismtek_favorite_game', true),
                'themeColor' => (string)get_user_meta($uid, 'prismtek_theme_color', true),
            ]);
        },
    ]);

    register_rest_route('prismtek/v1', '/profile', [
        'methods' => 'POST',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $uid = get_current_user_id();
            if (!$uid) return new WP_REST_Response(['ok' => false, 'error' => 'auth_required'], 401);
            $display = sanitize_text_field((string)$request->get_param('displayName'));
            $bio = sanitize_text_field((string)$request->get_param('bio'));
            $fav = sanitize_title((string)$request->get_param('favoriteGame'));
            $color = sanitize_hex_color((string)$request->get_param('themeColor'));

            if ($display !== '') {
                wp_update_user(['ID' => $uid, 'display_name' => mb_substr($display, 0, 24), 'nickname' => mb_substr($display, 0, 24)]);
            }
            update_user_meta($uid, 'prismtek_bio', mb_substr($bio, 0, 120));
            update_user_meta($uid, 'prismtek_favorite_game', mb_substr($fav, 0, 60));
            update_user_meta($uid, 'prismtek_theme_color', $color ?: '#59d9ff');

            return rest_ensure_response(['ok' => true]);
        },
    ]);

    

    register_rest_route('prismtek/v1', '/pet', [
        'methods' => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function () {
            $uid = get_current_user_id();
            if (!$uid) return new WP_REST_Response(['ok' => false, 'error' => 'auth_required'], 401);
            $state = prismtek_pet_get_state($uid);
            $unlock = prismtek_pet_get_unlocks($uid);
            $state['stage'] = prismtek_pet_compute_stage($state);
            $state['unlocks'] = $unlock;
            if (!in_array((string)($state['skin'] ?? 'default'), $unlock['skins'], true)) $state['skin'] = 'default';
            return rest_ensure_response(['ok' => true, 'pet' => $state]);
        },
    ]);

    register_rest_route('prismtek/v1', '/pet/action', [
        'methods' => 'POST',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $uid = get_current_user_id();
            if (!$uid) return new WP_REST_Response(['ok' => false, 'error' => 'auth_required'], 401);
            $action = sanitize_key((string)$request->get_param('action'));
            $state = prismtek_pet_get_state($uid);

            if ($action === 'feed') {
                $state['hunger'] = min(100, (int)$state['hunger'] + 22);
                $state['happiness'] = min(100, (int)$state['happiness'] + 4);
            } elseif ($action === 'play') {
                $state['happiness'] = min(100, (int)$state['happiness'] + 16);
                $state['energy'] = max(0, (int)$state['energy'] - 8);
                $state['hunger'] = max(0, (int)$state['hunger'] - 6);
            } elseif ($action === 'rest') {
                $state['energy'] = min(100, (int)$state['energy'] + 20);
                $state['happiness'] = min(100, (int)$state['happiness'] + 3);
            } elseif ($action === 'rename') {
                $name = sanitize_text_field((string)$request->get_param('name'));
                if ($name !== '') $state['name'] = mb_substr($name, 0, 20);
            } elseif ($action === 'setskin') {
                $skin = sanitize_key((string)$request->get_param('skin'));
                $unlock = prismtek_pet_get_unlocks($uid);
                if (in_array($skin, $unlock['skins'], true)) $state['skin'] = $skin;
            } else {
                return new WP_REST_Response(['ok' => false, 'error' => 'invalid_action'], 400);
            }

            // light health recovery when cared for
            if ((int)$state['hunger'] > 50 && (int)$state['energy'] > 40) {
                $state['health'] = min(100, (int)$state['health'] + 2);
            }

            prismtek_pet_set_state($uid, $state);
            $state = prismtek_pet_get_state($uid);
            $unlock = prismtek_pet_get_unlocks($uid);
            $state['stage'] = prismtek_pet_compute_stage($state);
            $state['unlocks'] = $unlock;
            return rest_ensure_response(['ok' => true, 'pet' => $state]);
        },
    ]);
register_rest_route('prismtek/v1', '/moderation/clear-chat', [
        'methods' => 'POST',
        'permission_callback' => function () { return current_user_can('manage_options'); },
        'callback' => function () {
            prismtek_pixel_set_chat_messages([]);
            return rest_ensure_response(['ok' => true]);
        },
    ]);

    register_rest_route('prismtek/v1', '/moderation/clear-wall', [
        'methods' => 'POST',
        'permission_callback' => function () { return current_user_can('manage_options'); },
        'callback' => function () {
            prismtek_pixel_set_wall_items([]);
            return rest_ensure_response(['ok' => true]);
        },
    ]);


});

function prismtek_pixel_scan_games() {
    $baseDir = WP_CONTENT_DIR . '/uploads/pixel-games';
    if (!is_dir($baseDir)) wp_mkdir_p($baseDir);

    $out = [];
    foreach (glob($baseDir . '/*') ?: [] as $entry) {
        if (!is_dir($entry)) continue;
        $slug = basename($entry);

        $index = $entry . '/index.html';
        $target = '';
        if (is_file($index)) {
            $target = $index;
        } else {
            $candidates = glob($entry . '/*.html') ?: [];
            if (!empty($candidates)) $target = $candidates[0];
        }
        if (!$target) continue;

        $fileName = basename($target);
        $url = content_url('uploads/pixel-games/' . rawurlencode($slug) . '/' . rawurlencode($fileName));
        $titleBase = $fileName === 'index.html' ? $slug : ($slug . ' - ' . pathinfo($fileName, PATHINFO_FILENAME));

        $out[] = [
            'slug' => sanitize_title($slug),
            'url' => $url,
            'title' => ucwords(str_replace(['-', '_'], ' ', $titleBase)),
        ];
    }

    usort($out, fn($a, $b) => strcmp($a['title'], $b['title']));
    return array_slice($out, 0, 24);
}


add_shortcode('prism_featured_games', function () {
    $games = array_slice(prismtek_pixel_scan_games(), 0, 8);
    if (empty($games)) return '<p>No featured games yet.</p>';
    ob_start(); ?>
    <div class="pph-featured" id="pph-featured-games">
      <button type="button" class="pph-fnav" data-dir="-1">◀</button>
      <div class="pph-ftrack" id="pph-ftrack">
        <?php foreach ($games as $g): ?>
          <a class="pph-fcard" href="/pixel-arcade/?game=<?php echo esc_attr($g['slug']); ?>"><?php echo esc_html($g['title']); ?></a>
        <?php endforeach; ?>
      </div>
      <button type="button" class="pph-fnav" data-dir="1">▶</button>
    </div>
    <style>
      .pph-featured{display:grid;grid-template-columns:40px 1fr 40px;gap:8px;align-items:center}
      .pph-ftrack{display:flex;gap:8px;overflow:auto;scroll-behavior:smooth;padding:4px}
      .pph-fcard{min-width:180px;padding:10px;border:1px solid #4c5498;background:#11173b;color:#fff;text-decoration:none}
      .pph-fnav{height:36px;background:#1b2458;color:#fff;border:1px solid #5e76ff;cursor:pointer}
    </style>
    <script>
      (()=>{const root=document.getElementById('pph-featured-games');if(!root)return;const t=root.querySelector('#pph-ftrack');root.querySelectorAll('.pph-fnav').forEach(b=>b.addEventListener('click',()=>t.scrollBy({left:(Number(b.dataset.dir)||1)*220,behavior:'smooth'})));})();
    </script>
    <?php return ob_get_clean();
});




add_shortcode('prism_pet_showcase', function () {
    $users = get_users(['number' => 12, 'orderby' => 'registered', 'order' => 'DESC']);
    $cards = [];
    foreach ($users as $u) {
        $uid = (int)$u->ID;
        $state = get_user_meta($uid, 'prismtek_pet_state', true);
        if (!is_array($state) || empty($state)) continue;
        $state = prismtek_pet_apply_decay($state);
        $stage = prismtek_pet_compute_stage($state);
        $cards[] = [
            'name' => (string)$u->display_name,
            'pet' => (string)($state['name'] ?? 'Prismo'),
            'stage' => $stage,
            'skin' => (string)($state['skin'] ?? 'default'),
            'health' => (int)($state['health'] ?? 0),
        ];
        if (count($cards) >= 8) break;
    }
    if (empty($cards)) return '<p>No creature profiles yet.</p>';
    ob_start(); ?>
    <div class="pph-showcase">
      <?php foreach ($cards as $c): ?>
        <div class="pph-scard">
          <strong><?php echo esc_html($c['name']); ?></strong><br>
          <?php echo esc_html($c['pet']); ?> · <?php echo esc_html($c['stage']); ?><br>
          Skin: <?php echo esc_html($c['skin']); ?> · HP <?php echo (int)$c['health']; ?>
        </div>
      <?php endforeach; ?>
    </div>
    <style>
      .pph-showcase{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:8px}
      .pph-scard{padding:10px;border:1px solid #4c5498;background:#11173b;color:#fff}
    </style>
    <?php return ob_get_clean();
});

add_shortcode('prism_pixel_hub', function () {
    $games = prismtek_pixel_scan_games();
    $can_moderate = current_user_can('manage_options');
    $viewer_logged_in = is_user_logged_in();
    $viewer_id = get_current_user_id();
    $viewer_nonce = $viewer_logged_in ? wp_create_nonce('wp_rest') : '';
    $viewer_user = $viewer_logged_in ? wp_get_current_user() : null;
    $profile_bio = $viewer_logged_in ? (string)get_user_meta($viewer_id, 'prismtek_bio', true) : '';
    $profile_fav = $viewer_logged_in ? (string)get_user_meta($viewer_id, 'prismtek_favorite_game', true) : '';
    $profile_color = $viewer_logged_in ? (string)get_user_meta($viewer_id, 'prismtek_theme_color', true) : '#59d9ff';
    $selected_game_slug = isset($_GET['game']) ? sanitize_title((string) $_GET['game']) : '';
    $selected_game = null;
    if (!empty($games) && $selected_game_slug !== '') {
        foreach ($games as $g) {
            if (($g['slug'] ?? '') === $selected_game_slug) { $selected_game = $g; break; }
        }
    }
    ob_start();
    ?>
    <section class="pph-wrap">
      <h2>Pixel Arcade & Community</h2>
      <p>Create and share pixel artwork, chat with the community, and play browser mini-games. Uploads support PNG, JPG, WEBP, and GIF up to 3MB.</p><p><strong>Safety:</strong> Community features are for age 13+ (or younger with parent/guardian permission).</p>

      <article class="pph-card">
        <details class="pph-toggle" data-toggle-key="account" open><summary>Account</summary>
        <p>Sign in to manage your content. Visitors can create accounts to join the community.</p>
        <p>
          <a href="<?php echo esc_url(wp_login_url(home_url('/pixel-arcade/'))); ?>">Login</a> ·
          <a href="<?php echo esc_url(wp_registration_url()); ?>">Create Account</a> ·
          <a href="/wp-admin/">Admin</a> ·
          <a href="<?php echo esc_url(wp_logout_url(home_url('/pixel-arcade/'))); ?>">Logout</a>
          <span id="pph-account-status" class="pph-status">Checking session…</span>
        </p>
        <?php if (!$viewer_logged_in): ?>
        <form id="pph-register-form" class="pph-form">
          <input name="username" type="text" minlength="3" maxlength="24" placeholder="Username" required />
          <input name="email" type="email" placeholder="Email" required />
          <input name="password" type="password" minlength="8" placeholder="Password (min 8 chars)" required />
          <label><input type="checkbox" name="age13" required /> I am 13+ or have parent/guardian permission</label>
          <button type="submit">Create Account with Password</button>
        </form>
        <p id="pph-register-status" class="pph-status"></p>
        <?php endif; ?>
        <?php if ($viewer_logged_in): ?>
        <form id="pph-profile-form" class="pph-form">
          <input name="displayName" type="text" maxlength="24" placeholder="Display name" value="<?php echo esc_attr((string)($viewer_user->display_name ?? '')); ?>" />
          <input name="bio" type="text" maxlength="120" placeholder="Short bio" value="<?php echo esc_attr($profile_bio); ?>" />
          <input name="favoriteGame" type="text" maxlength="60" placeholder="Favorite game slug" value="<?php echo esc_attr($profile_fav); ?>" />
          <label>Theme Color <input name="themeColor" type="color" value="<?php echo esc_attr($profile_color ?: '#59d9ff'); ?>" /></label>
          <button type="submit">Save Profile</button>
        </form>
        <p id="pph-profile-status" class="pph-status"></p>
        <?php endif; ?>
                <?php if ($viewer_logged_in): ?>
        <article id="pph-pet-panel" class="pph-card" style="margin-top:10px;">
          <details class="pph-toggle" data-toggle-key="pet"><summary>My Pixel Creature</summary>
          <div id="pph-pet-view" class="pph-pet-view">Loading pet...</div>
          <div class="pph-tool-row">
            <button type="button" id="pph-pet-feed">Feed</button>
            <button type="button" id="pph-pet-play">Play</button>
          </div>
          <div class="pph-tool-row">
            <button type="button" id="pph-pet-rest">Rest</button>
            <input id="pph-pet-name" type="text" maxlength="20" placeholder="Rename creature" />
          </div>
          <div class="pph-tool-row"><select id="pph-pet-skin"><option value="default">default</option></select><button type="button" id="pph-pet-skin-save">Apply Skin</button></div><button type="button" id="pph-pet-rename">Save Name</button>
          <p id="pph-pet-status" class="pph-status"></p>
          </details>
        </article>
        <?php endif; ?>
<?php if ($can_moderate): ?>
        <div class="pph-tool-row">
          <button type="button" id="pph-clear-chat">Clear Chat</button>
          <button type="button" id="pph-clear-wall">Clear Wall</button>
        </div>
        <div class="pph-tool-row">
          <input id="pph-reset-game" type="text" placeholder="Game slug (optional)" />
          <button type="button" id="pph-reset-scores">Reset Scores</button>
        </div>
        <p id="pph-mod-status" class="pph-status"></p>
        <?php endif; ?>
        </details>
      </article>

      <div class="pph-grid">
        <article class="pph-card">
          <details class="pph-toggle" data-toggle-key="games" open><summary>Mini HTML Games</summary>
          <p>Place game files in <code>/wp-content/uploads/pixel-games/&lt;game-folder&gt;/</code>. Supported: <code>index.html</code> or any <code>.html</code> file.</p>
          <?php if ($can_moderate): ?>
            <details class="pph-subtoggle" data-toggle-key="admin-tools">
              <summary>Upload / Admin Tools</summary>
              <p>Upload and metadata tools are hidden by default for cleaner browsing.</p>
              <form id="pph-game-upload-form" class="pph-form" enctype="multipart/form-data">
                <input name="title" type="text" maxlength="60" placeholder="Game title" />
                <input name="gameZip" type="file" accept=".zip,.html,.htm" required />
                <button type="submit">Upload Game</button>
              </form>
              <p id="pph-game-upload-status" class="pph-status"></p>
              <form id="pph-game-meta-form" class="pph-form">
                <input name="slug" type="text" placeholder="Game slug" />
                <input name="category" type="text" placeholder="Category (arcade/puzzle/racing)" />
                <input name="difficulty" type="text" placeholder="Difficulty (easy/normal/hard)" />
                <input name="controls" type="text" placeholder="Controls summary" />
                <input name="description" type="text" placeholder="Short description" />
                <button type="submit">Save Game Meta</button>
              </form>
              <p id="pph-game-meta-status" class="pph-status"></p>
            </details>
          <?php endif; ?>
          <?php if (!$games): ?>
            <p>No games are published yet. Add a game folder and refresh.</p>
          <?php else: ?>
            <input id="pph-game-search" type="text" placeholder="Search games..." />
            <div class="pph-games-list">
              <?php foreach ($games as $g): ?>
                <a class="pph-game-chip<?php echo (($selected_game['slug'] ?? '') === ($g['slug'] ?? '')) ? ' active' : ''; ?>" href="?game=<?php echo esc_attr($g['slug']); ?>"><?php echo esc_html($g['title']); ?></a>
              <?php endforeach; ?>
            </div>
            <?php if ($selected_game): ?>
              <div class="pph-game-embed">
                <iframe id="pph-game-frame" src="<?php echo esc_url($selected_game['url']); ?>" title="Pixel game preview" loading="lazy" sandbox="allow-scripts allow-same-origin allow-popups allow-forms"></iframe>
                <p>
                  <a href="<?php echo esc_url($selected_game['url']); ?>" target="_blank" rel="noopener">Open game in new tab</a> ·
                  <a href="<?php echo esc_url(remove_query_arg('game')); ?>" id="pph-stop-game">Stop game</a>
                </p>
                <div id="pph-game-meta" class="pph-leaderboard" data-game="<?php echo esc_attr($selected_game['slug'] ?? ''); ?>">Loading game details...</div>
                <div id="pph-leaderboard" class="pph-leaderboard" data-game="<?php echo esc_attr($selected_game['slug'] ?? ''); ?>">Loading leaderboard...</div>
              </div>
            <?php else: ?>
              <div class="pph-game-embed"><p>Select a game above to play in-page.</p></div>
            <?php endif; ?>
          <?php endif; ?>
          </details>
        </article>

        <article class="pph-card">
          <details class="pph-toggle" data-toggle-key="chat" open><summary>Community Chat</summary>
          <div id="pph-chat-log" class="pph-log">Loading chat...</div>
          <form id="pph-chat-form" class="pph-form">
            <input name="name" type="text" maxlength="24" placeholder="Name (optional)" />
            <input name="message" type="text" maxlength="280" placeholder="Share an update with the community..." required />
            <label><input type="checkbox" name="age13" required /> I am 13+ or have parent/guardian permission</label>
            <button type="submit">Send</button>
          </form>
          </details>
        </article>
      </div>



      <article class="pph-card">
        <details class="pph-toggle" data-toggle-key="studio"><summary>Pixel Studio</summary>
        <p>Draw directly in your browser, export as PNG, or publish to the Memory Wall scrapbook.</p>
        <div class="pph-studio-wrap">
          <div class="pph-canvas-shell"><canvas id="pph-studio-canvas" width="512" height="512" aria-label="Pixel drawing canvas"></canvas><canvas id="pph-grid-canvas" width="512" height="512" aria-hidden="true"></canvas></div>
          <div class="pph-studio-tools">
            <label>Tool
              <select id="pph-tool">
                <option value="pen" selected>Pen</option>
                <option value="line">Line</option>
                <option value="rect">Rectangle</option>
                <option value="circle">Circle</option>
                <option value="bucket">Paint Bucket</option>
                <option value="wand">Magic Wand</option>
                <option value="lasso">Lasso (rect)</option>
                <option value="eraser">Eraser</option>
                <option value="eyedropper">Eyedropper</option>
              </select>
            </label>
            <div class="pph-tool-row">
              <label>Color <input type="color" id="pph-color" value="#59d9ff" /></label>
              <label>Brush
                <select id="pph-brush">
                  <option value="1">1px</option>
                  <option value="2">2px</option>
                  <option value="3" selected>3px</option>
                  <option value="4">4px</option>
                  <option value="6">6px</option>
                </select>
              </label>
            </div>
            <div class="pph-tool-row">
              <label>Grid
                <select id="pph-grid-size">
                  <option value="32">32x32</option>
                  <option value="48">48x48</option>
                  <option value="64" selected>64x64</option>
                  <option value="96">96x96</option>
                  <option value="128">128x128</option>
                </select>
              </label>
              <label>Tolerance <input type="range" id="pph-tolerance" min="0" max="96" value="24" /></label>
              <label><input type="checkbox" id="pph-grid-toggle" checked /> Show Grid</label>
            </div>
            <div class="pph-tool-row">
              <button type="button" id="pph-undo">Undo</button>
              <button type="button" id="pph-redo">Redo</button>
              <button type="button" id="pph-clear">Clear</button>
            </div>
            <div class="pph-tool-row">
              <input id="pph-import-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif" />
              <button type="button" id="pph-import">Import Image</button>
              <button type="button" id="pph-strip-grid">Remove Grid Lines</button>
            </div>
            <button type="button" id="pph-download">Download PNG</button>
            <button type="button" id="pph-post-wall">Publish to Memory Wall</button>
          </div>
        </div>
        </details>
      </article>

      <article class="pph-card">
        <details class="pph-toggle" data-toggle-key="wall"><summary>Memory Wall / Visitor Scrapbook</summary>
        <form id="pph-wall-form" class="pph-form" enctype="multipart/form-data">
          <input name="name" type="text" maxlength="24" placeholder="Artist name" />
          <input name="caption" type="text" maxlength="120" placeholder="Caption" />
          <input name="tags" type="text" maxlength="120" placeholder="Tags (comma separated)" />
          <input name="image" type="file" accept="image/png,image/jpeg,image/webp,image/gif" required />
          <label><input type="checkbox" name="age13" required /> I am 13+ or have parent/guardian permission</label>
          <button type="submit">Upload Pixel Art</button>
        </form>
        <div id="pph-wall-grid" class="pph-wall">Loading gallery...</div>
        </details>
      </article>
    </section>

    <style>
      .pph-wrap{margin-top:1.5rem;display:grid;gap:16px}
      .pph-toggle,.pph-subtoggle{border:1px solid #4c5498;background:rgba(17,23,59,.35);padding:8px}
      .pph-toggle>summary,.pph-subtoggle>summary{cursor:pointer;list-style:none;font-family:"Press Start 2P",ui-monospace,monospace;font-size:.72rem;color:#fff;text-shadow:1px 1px 0 #000;padding:4px 2px}
      .pph-toggle[open]>summary,.pph-subtoggle[open]>summary{margin-bottom:8px}
      .pph-toggle>summary::-webkit-details-marker,.pph-subtoggle>summary::-webkit-details-marker{display:none}
      .pph-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}
      .pph-card{background:rgba(24,25,58,.92);border:2px solid #7e85ff;box-shadow:6px 6px 0 rgba(61,68,138,.68);padding:16px}
      .pph-card h3{margin-top:0;font-size:1rem;letter-spacing:.02em;color:#fff;text-shadow:1px 1px 0 #000}
      .pph-card p,.pph-card li,.pph-card label,.pph-card span{color:#fff;text-shadow:1px 1px 0 #000}
      .pph-log{height:240px;overflow:auto;background:#0f1130;border:1px solid #3c4379;padding:10px;font-family:ui-monospace,monospace;white-space:normal;word-break:break-word;overflow-wrap:anywhere}
      .pph-form{display:grid;gap:8px;margin-top:10px;min-width:0}
      .pph-form input,.pph-form button{padding:10px;border:1px solid #40488a;background:#101330;color:#eef1ff;min-width:0;max-width:100%}
      .pph-form button{background:linear-gradient(135deg,#7f65ff,#59d9ff);border:2px solid #dfe3ff;color:#fff;font-weight:700;cursor:pointer}
      #pph-game-search{width:100%;padding:8px;border:1px solid #40488a;background:#101330;color:#fff;margin-bottom:8px}
      .pph-games-list{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0 10px}
      .pph-game-chip{display:inline-block;padding:6px 10px;border:1px solid #4c5498;background:#11173b;color:#fff;text-decoration:none;font-size:11px}
      .pph-game-chip.active{background:#2a3272;border-color:#9fb1ff}
      .pph-game-embed{max-width:100%;overflow:hidden}
      .pph-game-embed iframe{margin-top:10px;width:100%;max-width:100%;height:min(78vh,680px);min-height:520px;border:1px solid #4b5395;background:#090b1f;display:block}
      .pph-leaderboard{margin-top:8px;padding:8px;border:1px solid #4c5498;background:#0f1130;font-size:11px;line-height:1.4}
      .pph-lrow{display:flex;align-items:center;gap:8px;margin:4px 0}
      .pph-ava{width:18px;height:18px;border-radius:50%;display:inline-grid;place-items:center;background:#2a3272;color:#fff;font-size:10px;overflow:hidden}
      .pph-wall{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:10px;margin-top:12px}
      .pph-wall a{display:block;border:1px solid #4c5498;background:#0f1130;padding:6px;text-decoration:none;color:#dde2ff;position:relative}
      .pph-del{margin-top:6px;padding:4px 6px;border:1px solid #c66;background:#431d1d;color:#fff;font-size:10px;cursor:pointer}
      .pph-status{display:block;margin-top:8px;font-size:11px;color:#ffe08a;text-shadow:1px 1px 0 #000}
      .pph-wall img{width:100%;height:96px;object-fit:cover;image-rendering:pixelated;display:block}
      .pph-cap{font-size:11px;line-height:1.3;margin-top:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .pph-msg{margin:0 0 8px}
      .pph-msg b{color:#fff}
      .pph-react,.pph-reply{margin-top:2px;margin-right:3px;padding:0 3px !important;border:1px solid #4c5498 !important;background:#11173b !important;color:#fff !important;font-size:7px !important;line-height:1.1 !important;display:inline-flex;align-items:center;gap:2px;cursor:pointer;min-height:12px !important;text-transform:none !important;letter-spacing:0 !important;border-radius:0 !important;box-shadow:none !important;transform:none !important}
      .pph-react:hover,.pph-reply:hover{box-shadow:none !important;transform:none !important;opacity:.92}
      .pph-wrap,.pph-wrap *{box-sizing:border-box;max-width:100%}
      .pph-wrap{overflow-x:hidden}
      .pph-wrap code{word-break:break-all;overflow-wrap:anywhere}
      .pph-grid{grid-template-columns:repeat(auto-fit,minmax(300px,1fr));min-width:0}
      .pph-card{min-width:0;overflow:hidden}
      .pph-card ul{padding-left:18px;margin:0}
      .pph-game-embed iframe{max-width:100%}
      .pph-studio-wrap{display:grid;grid-template-columns:minmax(0,520px) minmax(0,1fr);gap:12px;align-items:start;min-width:0}
      .pph-canvas-shell{position:relative;width:100%;max-width:520px;aspect-ratio:1/1}
      #pph-studio-canvas,#pph-grid-canvas{position:absolute;inset:0;width:100%;height:100%;border:2px solid #6b74c7;background:#0e1026;image-rendering:pixelated;cursor:crosshair;display:block}
      #pph-grid-canvas{pointer-events:none;background:transparent}
      .pph-studio-tools{display:grid;gap:8px;min-width:0}
      .pph-tool-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;min-width:0}
      .pph-studio-tools label{display:grid;gap:4px;font-size:12px;color:#fff;text-shadow:1px 1px 0 #000}
      .pph-studio-tools select,.pph-studio-tools input[type="color"],.pph-studio-tools input[type="range"],.pph-studio-tools input[type="file"],.pph-studio-tools button{padding:8px;border:1px solid #40488a;background:#101330;color:#eef1ff;min-width:0}
      .pph-studio-tools button{cursor:pointer}
      @media (max-width:1100px){.pph-grid{grid-template-columns:1fr}.pph-studio-wrap{grid-template-columns:1fr}}
      @media (max-width:768px){
        .pph-wrap{gap:12px}
        .pph-card{padding:12px}
        .pph-log{height:200px}
        .pph-form input,.pph-form button,.pph-studio-tools select,.pph-studio-tools input[type="color"],.pph-studio-tools input[type="range"],.pph-studio-tools input[type="file"],.pph-studio-tools button{width:100%}
        .pph-tool-row{grid-template-columns:1fr}
        .pph-game-embed iframe{height:min(68vh,560px);min-height:420px}
      }
    </style>

    <script>
    (()=>{
      const API = '<?php echo esc_js(rest_url('prismtek/v1/')); ?>';
      function initTogglePersistence(){
        try{
          const toggles=[...document.querySelectorAll('.pph-toggle, .pph-subtoggle')];
          toggles.forEach((el,idx)=>{
            const k = (el.getAttribute('data-toggle-key') || ('idx-'+idx)).toLowerCase();
            const ls = localStorage.getItem('pph_toggle_'+k);
            if(ls==='0') el.open=false;
            if(ls==='1') el.open=true;
            el.addEventListener('toggle', ()=>{
              localStorage.setItem('pph_toggle_'+k, el.open ? '1' : '0');
            });
          });
        }catch{}
      }
      initTogglePersistence();
      let canModerate = <?php echo $can_moderate ? 'true' : 'false'; ?>;
      let restNonce = '<?php echo esc_js($viewer_nonce); ?>';
      let isLoggedIn = <?php echo $viewer_logged_in ? 'true' : 'false'; ?>;
      let sessionUserId = <?php echo (int) $viewer_id; ?>;
      const chatLog = document.getElementById('pph-chat-log');
      const chatForm = document.getElementById('pph-chat-form');
      const wallForm = document.getElementById('pph-wall-form');
      const wallGrid = document.getElementById('pph-wall-grid');
      const registerForm = document.getElementById('pph-register-form');
      const registerStatus = document.getElementById('pph-register-status');
      const gameUploadForm = document.getElementById('pph-game-upload-form');
      const gameUploadStatus = document.getElementById('pph-game-upload-status');
      const gameMetaForm = document.getElementById('pph-game-meta-form');
      const gameMetaStatus = document.getElementById('pph-game-meta-status');
      const gameSearch = document.getElementById('pph-game-search');
      const profileForm = document.getElementById('pph-profile-form');
      const profileStatus = document.getElementById('pph-profile-status');
      const clearChatBtn = document.getElementById('pph-clear-chat');
      const clearWallBtn = document.getElementById('pph-clear-wall');
      const modStatus = document.getElementById('pph-mod-status');
      const petView = document.getElementById('pph-pet-view');
      const petStatus = document.getElementById('pph-pet-status');
      const petFeedBtn = document.getElementById('pph-pet-feed');
      const petPlayBtn = document.getElementById('pph-pet-play');
      const petRestBtn = document.getElementById('pph-pet-rest');
      const petRenameBtn = document.getElementById('pph-pet-rename');
      const petNameInput = document.getElementById('pph-pet-name');
      const petSkinSelect = document.getElementById('pph-pet-skin');
      const petSkinSaveBtn = document.getElementById('pph-pet-skin-save');
      const resetGameInput = document.getElementById('pph-reset-game');
      const resetScoresBtn = document.getElementById('pph-reset-scores');
      const studioCanvas = document.getElementById('pph-studio-canvas');
      const gridCanvas = document.getElementById('pph-grid-canvas');
      const colorInput = document.getElementById('pph-color');
      const brushInput = document.getElementById('pph-brush');
      const gridInput = document.getElementById('pph-grid-size');
      const eraserBtn = document.getElementById('pph-eraser');
      const clearBtn = document.getElementById('pph-clear');
      const downloadBtn = document.getElementById('pph-download');
      const postWallBtn = document.getElementById('pph-post-wall');
      const toolInput = document.getElementById('pph-tool');
      const toleranceInput = document.getElementById('pph-tolerance');
      const gridToggle = document.getElementById('pph-grid-toggle');
      const undoBtn = document.getElementById('pph-undo');
      const redoBtn = document.getElementById('pph-redo');
      const importBtn = document.getElementById('pph-import');
      const importFile = document.getElementById('pph-import-file');
      const gameFrame = document.getElementById('pph-game-frame');
      const stopGameLink = document.getElementById('pph-stop-game');
      const leaderboard = document.getElementById('pph-leaderboard');
      const gameMetaBox = document.getElementById('pph-game-meta');
      const stripGridBtn = document.getElementById('pph-strip-grid');
      const accountStatus = document.getElementById('pph-account-status');
      const ago = (ts)=>{
        const s=Math.max(1,Math.floor(Date.now()/1000-ts));
        if(s<60)return s+'s'; if(s<3600)return Math.floor(s/60)+'m'; if(s<86400)return Math.floor(s/3600)+'h';
        return Math.floor(s/86400)+'d';
      };

      async function bootstrapSession(){
        try{
          const r = await fetch(API+'session?ts='+Date.now(), { credentials:'include', cache:'no-store', headers: restNonce ? {'X-WP-Nonce':restNonce} : {} });
          const j = await r.json();
          isLoggedIn = !!j.loggedIn;
          canModerate = !!j.canModerate;
          restNonce = j.nonce || '';
          sessionUserId = Number(j.userId || 0);
          try {
            if(sessionUserId>0 && j.user){ localStorage.setItem('pixel_player_name', String(j.user)); }
            if(!localStorage.getItem('pixel_player_key')){ localStorage.setItem('pixel_player_key', 'pk_'+Math.random().toString(36).slice(2)+Date.now().toString(36)); }
          } catch {}
          if(accountStatus){
            if(isLoggedIn){
              accountStatus.textContent = canModerate ? `Logged in as ${j.user || 'user'} (admin)` : `Logged in as ${j.user || 'user'}`;
            } else {
              accountStatus.textContent = 'Not logged in';
            }
          }
        }catch{}
      };


      async function loadChat(){
        try{
          const r=await fetch(API+'chat'); const j=await r.json();
          const rows=(j.messages||[]).slice(-60);
          chatLog.innerHTML = rows.map(m=>{
            const re=m.reactions||{};
            const rid=(m.id||'');
            const reply=m.replyTo?`<em>↪ ${String(m.replyTo).replace(/[<>]/g,'')}</em><br>`:'';
            const up = Number(re['up']||re['👍']||0);
            const heart = Number(re['heart']||re['❤️']||0);
            const fire = Number(re['fire']||re['🔥']||0);
            return `<p class="pph-msg"><b>${(m.name||'Community Member').replace(/[<>]/g,'')}</b> · ${ago(m.ts)}<br>${reply}${(m.message||'').replace(/[<>]/g,'')}<br><button class="pph-react" data-id="${rid}" data-e="up">👍 ${up}</button><button class="pph-react" data-id="${rid}" data-e="heart">❤️ ${heart}</button><button class="pph-react" data-id="${rid}" data-e="fire">🔥 ${fire}</button><button class="pph-reply" data-name="${(m.name||'Community Member').replace(/[<>]/g,'')}">Reply</button>${(canModerate || (isLoggedIn && Number(m.userId||0)===sessionUserId)) ? `<button class=\"pph-reply pph-msg-del\" data-id=\"${rid}\">Remove</button>` : ''}</p>`;
          }).join('') || 'No messages yet.';
          chatLog.querySelectorAll('.pph-react').forEach(btn=>btn.addEventListener('click', async ()=>{
            await fetch(API+'chat/react',{method:'POST',credentials:'include',headers:{'content-type':'application/json'},body:JSON.stringify({id:btn.dataset.id,emoji:btn.dataset.e})});
            loadChat();
          }));
          chatLog.querySelectorAll('.pph-msg-del').forEach(btn=>btn.addEventListener('click', async ()=>{
            const id = btn.getAttribute('data-id');
            if(!id) return;
            const r = await fetch(API+'chat/'+encodeURIComponent(id), { method:'DELETE', credentials:'include', headers:{'X-WP-Nonce':restNonce} });
            if(!r.ok) return;
            loadChat();
          }));
          chatLog.querySelectorAll('.pph-reply').forEach(btn=>btn.addEventListener('click', ()=>{
            const nm=btn.dataset.name||'Community Member';
            const inp=chatForm?.querySelector('input[name=message]');
            if(inp){ inp.value=`@${nm} `; inp.focus(); }
          }));
          chatLog.scrollTop = chatLog.scrollHeight;
        }catch{ chatLog.textContent='Chat unavailable right now.'; }
      }


      
      async function loadGameMeta(){
        if(!gameMetaBox) return;
        const game = gameMetaBox.getAttribute('data-game') || '';
        if(!game){ gameMetaBox.textContent='No game selected.'; return; }
        try{
          const r=await fetch(API+'games/meta?slug='+encodeURIComponent(game)+'&ts='+Date.now(),{credentials:'include',cache:'no-store'});
          const j=await r.json();
          const m=j.meta||{};
          const cat=(m.category||'arcade').toString();
          const diff=(m.difficulty||'normal').toString();
          const ctl=(m.controls||'See game panel').toString();
          const desc=(m.description||'No description yet.').toString();
          gameMetaBox.innerHTML=`<strong>${game}</strong><br>Category: ${cat} · Difficulty: ${diff}<br>Controls: ${ctl}<br>${desc}`;
        }catch{ gameMetaBox.textContent='Game details unavailable right now.'; }
      }


      function renderPet(pet){
        if(!petView || !pet) return;
        const mood = (pet.happiness>70 && pet.energy>50) ? 'Happy' : (pet.health<35 ? 'Sickly' : 'Okay');
        const stage = (pet.stage||'baby');
        const skin = (pet.skin||'default');
        petView.innerHTML = `<strong>${(pet.name||'Prismo')}</strong> (${pet.species||'blob'}) · ${mood}<br>Stage ${stage} · Skin ${skin}<br>Hunger ${pet.hunger}% · Happiness ${pet.happiness}% · Energy ${pet.energy}% · Health ${pet.health}%`;
        if(petNameInput && !petNameInput.value) petNameInput.value = pet.name || '';
        if(petSkinSelect){
          const skins = (pet.unlocks && Array.isArray(pet.unlocks.skins)) ? pet.unlocks.skins : ['default'];
          petSkinSelect.innerHTML = skins.map(sk=>`<option value=\"${sk}\" ${sk===skin?'selected':''}>${sk}</option>`).join('');
        }
      }

      async function loadPet(){
        if(!petView) return;
        try{
          const r = await fetch(API+'pet?ts='+Date.now(), { credentials:'include', cache:'no-store' });
          if(!r.ok){ petView.textContent='Log in to care for your creature.'; return; }
          const j = await r.json();
          renderPet(j.pet||null);
        }catch{ petView.textContent='Pet unavailable right now.'; }
      }

      async function petAction(action, extra={}){
        if(!petStatus) return;
        petStatus.textContent = 'Working...';
        const payload = Object.assign({ action }, extra||{});
        const r = await fetch(API+'pet/action', { method:'POST', credentials:'include', headers:{'content-type':'application/json','X-WP-Nonce':restNonce}, body:JSON.stringify(payload) });
        if(!r.ok){ petStatus.textContent='Action failed.'; return; }
        const j = await r.json();
        renderPet(j.pet||null);
        petStatus.textContent = 'Done.';
      }

async function loadLeaderboard(){
        if(!leaderboard) return;
        const game = leaderboard.getAttribute('data-game') || '';
        if(!game){ leaderboard.textContent='No game selected.'; return; }
        try {
          const r = await fetch(API+'scores?game='+encodeURIComponent(game)+'&ts='+Date.now(), { credentials:'include', cache:'no-store' });
          const j = await r.json();
          const top = Array.isArray(j.top) ? j.top : [];
          if(!top.length){ leaderboard.textContent='Top 3: no scores yet — be the first!'; return; }
          leaderboard.innerHTML = '<strong>Top 3</strong>' + top.map((e,i)=>{
            const nm=((e.name||'Guest')+'').replace(/[<>]/g,'');
            const init=(e.initial||nm.slice(0,1)||'G').toString().toUpperCase();
            const av = e.avatar ? `<span class=\"pph-ava\"><img src=\"${e.avatar}\" alt=\"avatar\" style=\"width:100%;height:100%;object-fit:cover\"></span>` : `<span class=\"pph-ava\">${init}</span>`;
            return `<div class=\"pph-lrow\">${av}<span>#${i+1} ${nm} (${Number(e.score||0)})</span></div>`;
          }).join('');
        } catch {
          leaderboard.textContent='Leaderboard unavailable right now.';
        }
      }

      async function loadWall(){
        try{
          const r=await fetch(API+'pixel-wall?ts='+Date.now(), { credentials:'include', cache:'no-store' }); const j=await r.json();
          const items=(j.items||[]);
          wallGrid.innerHTML = items.map(it=>{
            const who=(it.name||'Community Member').replace(/[<>]/g,'');
            const cap=(it.caption||'').replace(/[<>]/g,'');
            const canDelete = canModerate || (isLoggedIn && sessionUserId > 0 && Number(it.userId||0) === sessionUserId);
            const tags=Array.isArray(it.tags)?it.tags:[];
            const tagTxt=tags.length?(' #'+tags.join(' #')):'';
            const del = canDelete ? `<button class=\"pph-del\" data-id=\"${it.id}\">Remove</button>` : '';
            const feat = canModerate ? `<button class=\"pph-del pph-feature\" data-id=\"${it.id}\" data-f=\"${it.featured?0:1}\">${it.featured?'Unfeature':'Feature'}</button>` : '';
            const badge = it.featured ? `<div class=\"pph-cap\">⭐ Featured</div>` : '';
            return `<a href=\"${it.url}\" target=\"_blank\" rel=\"noopener\"><img src=\"${it.url}\" alt=\"pixel art\"/>${badge}<div class=\"pph-cap\">${who} · ${cap}${tagTxt}</div>${del}${feat}</a>`;
          }).join('') || 'No artwork has been published yet. Be the first to add to the scrapbook.';
          if (isLoggedIn) {
            wallGrid.querySelectorAll('.pph-del').forEach(btn=>btn.addEventListener('click', async (e)=>{
              e.preventDefault();
              const id = btn.getAttribute('data-id');
              if(!id) return;
              const r = await fetch(API+'pixel-wall/'+encodeURIComponent(id), { method:'DELETE', credentials:'include', headers:{'X-WP-Nonce':restNonce} });
              if(!r.ok){
                let msg='Delete failed.';
                if(r.status===401) msg='Please log in first.';
                if(r.status===403) msg='You can only remove your own images (or be admin).';
                alert(msg);
                return;
              }
              loadWall();
            }));
          }
        }catch{ wallGrid.textContent='Gallery unavailable right now.'; }
      }

      chatForm?.addEventListener('submit', async (e)=>{
        e.preventDefault();
        const fd=new FormData(chatForm);
        const msg=String(fd.get('message')||'');
        const m=msg.match(/^@([^\s]{1,24})\s+/);
        const payload={name:fd.get('name')||'', message:msg, replyTo:m?m[1]:'', age13: !!fd.get('age13')};
        if(!payload.message) return;
        const res=await fetch(API+'chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(payload)});
        if(res.ok){ chatForm.reset(); loadChat(); }
      });

      // --- Pixel Studio ---
      const studio = (() => {
        if(!studioCanvas) return null;
        const ctx = studioCanvas.getContext('2d', { alpha: false, willReadFrequently: true });
        const gctx = gridCanvas ? gridCanvas.getContext('2d') : null;
        let grid = Number(gridInput?.value || 64);
        let cell = studioCanvas.width / grid;
        const bg = '#0e1026';
        let drawing = false;
        let start = null;
        let snapshot = null;
        let tool = (toolInput?.value || 'pen');
        let showGrid = !!gridToggle?.checked;
        let history = [];
        let future = [];

        function clamp(v,min,max){ return Math.max(min,Math.min(max,v)); }
        function toPx(g){ return Math.round(g * cell); }
        function pushHistory(){ history.push(ctx.getImageData(0,0,studioCanvas.width,studioCanvas.height)); if(history.length>50) history.shift(); future=[]; }
        function undo(){ if(!history.length) return; future.push(ctx.getImageData(0,0,studioCanvas.width,studioCanvas.height)); ctx.putImageData(history.pop(),0,0); }
        function redo(){ if(!future.length) return; history.push(ctx.getImageData(0,0,studioCanvas.width,studioCanvas.height)); ctx.putImageData(future.pop(),0,0); }

        function drawGuides() {
          if(!gctx) return;
          gctx.clearRect(0,0,gridCanvas.width,gridCanvas.height);
          if(!showGrid) return;
          gctx.save();
          gctx.strokeStyle = 'rgba(255,255,255,0.10)';
          gctx.lineWidth = 1;
          for(let i=1;i<grid;i++){
            const p = Math.round(i*cell)+0.5;
            gctx.beginPath(); gctx.moveTo(p,0); gctx.lineTo(p,gridCanvas.height); gctx.stroke();
            gctx.beginPath(); gctx.moveTo(0,p); gctx.lineTo(gridCanvas.width,p); gctx.stroke();
          }
          gctx.restore();
        }

        function resetCanvas() {
          ctx.fillStyle = bg;
          ctx.fillRect(0,0,studioCanvas.width,studioCanvas.height);
          drawGuides();
          history=[]; future=[];
        }

        function pxFromEvent(e){
          const r=studioCanvas.getBoundingClientRect();
          const x=(e.clientX-r.left)*(studioCanvas.width/r.width);
          const y=(e.clientY-r.top)*(studioCanvas.height/r.height);
          const gx=clamp(Math.floor(x/cell),0,grid-1);
          const gy=clamp(Math.floor(y/cell),0,grid-1);
          return {gx,gy};
        }

        function currentColor(){ return tool==='eraser' ? bg : (colorInput?.value || '#59d9ff'); }

        function setCell(gx,gy,color){
          if(gx<0||gy<0||gx>=grid||gy>=grid) return;
          ctx.fillStyle = color;
          ctx.fillRect(toPx(gx),toPx(gy),Math.ceil(cell),Math.ceil(cell));
        }

        function getCellColor(gx,gy){
          const img = ctx.getImageData(toPx(gx)+1,toPx(gy)+1,1,1).data;
          return [img[0],img[1],img[2]];
        }

        function colorDist(a,b){ return Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])+Math.abs(a[2]-b[2]); }
        function hexToRgb(hex){ const h=hex.replace('#',''); return [parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)]; }

        function paint(gx,gy){
          const b=Math.max(1,Number(brushInput?.value||1));
          const col=currentColor();
          for(let yy=0;yy<b;yy++) for(let xx=0;xx<b;xx++) setCell(gx+xx,gy+yy,col);
          drawGuides();
        }

        function drawLine(a,b,col){
          let x0=a.gx,y0=a.gy,x1=b.gx,y1=b.gy;
          const dx=Math.abs(x1-x0), sx=x0<x1?1:-1;
          const dy=-Math.abs(y1-y0), sy=y0<y1?1:-1;
          let err=dx+dy;
          while(true){ setCell(x0,y0,col); if(x0===x1&&y0===y1) break; const e2=2*err; if(e2>=dy){err+=dy;x0+=sx;} if(e2<=dx){err+=dx;y0+=sy;} }
        }

        function drawRect(a,b,col){
          const x0=Math.min(a.gx,b.gx), y0=Math.min(a.gy,b.gy), x1=Math.max(a.gx,b.gx), y1=Math.max(a.gy,b.gy);
          for(let x=x0;x<=x1;x++){ setCell(x,y0,col); setCell(x,y1,col); }
          for(let y=y0;y<=y1;y++){ setCell(x0,y,col); setCell(x1,y,col); }
        }

        function drawCircle(a,b,col){
          const rx=Math.max(1,Math.abs(b.gx-a.gx));
          const ry=Math.max(1,Math.abs(b.gy-a.gy));
          for(let t=0;t<360;t+=2){
            const rad=t*Math.PI/180;
            const x=Math.round(a.gx + rx*Math.cos(rad));
            const y=Math.round(a.gy + ry*Math.sin(rad));
            setCell(x,y,col);
          }
        }

        function floodFill(startX,startY,replHex,smart=false){
          const tol = Number(toleranceInput?.value || 24);
          const target = getCellColor(startX,startY);
          const repl = hexToRgb(replHex);
          if(colorDist(target,repl)<3) return;
          const q=[[startX,startY]];
          const seen=new Set();
          while(q.length){
            const [x,y]=q.pop();
            const key=x+','+y; if(seen.has(key)) continue; seen.add(key);
            if(x<0||y<0||x>=grid||y>=grid) continue;
            const c=getCellColor(x,y);
            if(colorDist(c,target) > (smart ? tol : 8)) continue;
            setCell(x,y,replHex);
            q.push([x+1,y],[x-1,y],[x,y+1],[x,y-1]);
          }
          drawGuides();
        }

        function pickColor(gx,gy){
          const [r,g,b]=getCellColor(gx,gy);
          const hex='#'+[r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('');
          if(colorInput) colorInput.value = hex;
        }

        function previewShape(pos){
          if(!snapshot || !start) return;
          ctx.putImageData(snapshot,0,0);
          const col=currentColor();
          if(tool==='line') drawLine(start,pos,col);
          if(tool==='rect' || tool==='lasso') drawRect(start,pos,col);
          if(tool==='circle') drawCircle(start,pos,col);
          drawGuides();
        }

        studioCanvas.addEventListener('pointerdown', (e)=>{
          const p=pxFromEvent(e);
          tool = toolInput?.value || tool;
          if(['bucket','wand','eyedropper'].includes(tool)){
            pushHistory();
            if(tool==='bucket') floodFill(p.gx,p.gy,currentColor(),false);
            if(tool==='wand') floodFill(p.gx,p.gy,currentColor(),true);
            if(tool==='eyedropper') pickColor(p.gx,p.gy);
            return;
          }
          drawing=true; start=p; pushHistory(); snapshot=ctx.getImageData(0,0,studioCanvas.width,studioCanvas.height);
          if(tool==='pen' || tool==='eraser'){ paint(p.gx,p.gy); }
        });

        window.addEventListener('pointerup', (e)=>{
          if(!drawing) return;
          drawing=false;
          const p=pxFromEvent(e);
          if(['line','rect','circle','lasso'].includes(tool)){
            previewShape(p);
          }
          snapshot=null;
        });

        studioCanvas.addEventListener('pointermove', (e)=>{
          if(!drawing) return;
          const p=pxFromEvent(e);
          if(tool==='pen' || tool==='eraser'){ paint(p.gx,p.gy); return; }
          previewShape(p);
        });

        gridInput?.addEventListener('change', ()=>{
          grid = Number(gridInput.value||64);
          cell = studioCanvas.width / grid;
          resetCanvas();
        });

        toolInput?.addEventListener('change', ()=>{ tool = toolInput.value || 'pen'; });
        gridToggle?.addEventListener('change', ()=>{ showGrid = !!gridToggle.checked; drawGuides(); });
        clearBtn?.addEventListener('click', ()=> resetCanvas());
        undoBtn?.addEventListener('click', ()=> undo());
        redoBtn?.addEventListener('click', ()=> redo());


        function removeImportedGridLines(autoRun=false){
          const img = ctx.getImageData(0,0,studioCanvas.width,studioCanvas.height);
          const d = img.data;
          const step = Math.max(2, Math.round(cell));
          const isDark = (r,g,b)=> (r+g+b) < (autoRun ? 180 : 120);
          const idx=(x,y)=> (y*studioCanvas.width + x)*4;

          // vertical lines
          for(let x=step; x<studioCanvas.width-1; x+=step){
            for(let y=1; y<studioCanvas.height-1; y++){
              const i=idx(x,y), l=idx(x-1,y), r=idx(x+1,y);
              if(isDark(d[i],d[i+1],d[i+2])){
                d[i]=(d[l]+d[r])>>1; d[i+1]=(d[l+1]+d[r+1])>>1; d[i+2]=(d[l+2]+d[r+2])>>1;
              }
            }
          }
          // horizontal lines
          for(let y=step; y<studioCanvas.height-1; y+=step){
            for(let x=1; x<studioCanvas.width-1; x++){
              const i=idx(x,y), u=idx(x,y-1), b=idx(x,y+1);
              if(isDark(d[i],d[i+1],d[i+2])){
                d[i]=(d[u]+d[b])>>1; d[i+1]=(d[u+1]+d[b+1])>>1; d[i+2]=(d[u+2]+d[b+2])>>1;
              }
            }
          }
          ctx.putImageData(img,0,0);
          drawGuides();
        }

        stripGridBtn?.addEventListener('click', ()=>{ pushHistory(); removeImportedGridLines(); });

        importBtn?.addEventListener('click', ()=>{
          const f = importFile?.files?.[0];
          if(!f) return;
          const img = new Image();
          img.onload = ()=>{
            pushHistory();
            ctx.fillStyle = bg; ctx.fillRect(0,0,studioCanvas.width,studioCanvas.height);
            ctx.imageSmoothingEnabled = false;
            ctx.drawImage(img,0,0,studioCanvas.width,studioCanvas.height);
            // auto-clean common imported grid lines immediately
            removeImportedGridLines(true);
            drawGuides();
          };
          img.src = URL.createObjectURL(f);
        });

        downloadBtn?.addEventListener('click', ()=>{
          const a=document.createElement('a');
          a.href=studioCanvas.toDataURL('image/png');
          a.download='pixel-art.png';
          a.click();
        });

        postWallBtn?.addEventListener('click', async ()=>{
          postWallBtn.disabled = true;
          postWallBtn.textContent = 'Publishing...';
          const blob = await new Promise(res=>studioCanvas.toBlob(res,'image/png'));
          const fd = new FormData();
          const ts = Date.now();
          fd.append('name','Artist');
          fd.append('caption','Created in Pixel Studio');
          fd.append('image', blob, `pixel-studio-${ts}.png`);
          const res = await fetch(API+'pixel-wall',{method:'POST',credentials:'include',body:fd});
          if(res.ok){ loadWall(); }
          postWallBtn.disabled = false;
          postWallBtn.textContent = 'Publish to Memory Wall';
        });

        resetCanvas();
        if(gridToggle){ showGrid = !!gridToggle.checked; drawGuides(); }
        return { resetCanvas };
      })();

      gameSearch?.addEventListener('input', ()=>{
        const q=(gameSearch.value||'').toLowerCase().trim();
        document.querySelectorAll('.pph-game-chip').forEach(el=>{
          const t=(el.textContent||'').toLowerCase();
          el.style.display = (!q || t.includes(q)) ? '' : 'none';
        });
      });

      stopGameLink?.addEventListener('click', (e)=>{
        if(gameFrame){
          e.preventDefault();
          gameFrame.src = 'about:blank';
          const clean = window.location.pathname;
          history.replaceState({}, '', clean);
        }
      });

            profileForm?.addEventListener('submit', async (e)=>{
        e.preventDefault();
        const fd = new FormData(profileForm);
        const payload = {
          displayName: String(fd.get('displayName')||'').trim(),
          bio: String(fd.get('bio')||'').trim(),
          favoriteGame: String(fd.get('favoriteGame')||'').trim(),
          themeColor: String(fd.get('themeColor')||'#59d9ff').trim()
        };
        if(profileStatus) profileStatus.textContent='Saving profile...';
        const r = await fetch(API+'profile', { method:'POST', credentials:'include', headers:{'content-type':'application/json','X-WP-Nonce':restNonce}, body:JSON.stringify(payload) });
        if(!r.ok){ if(profileStatus) profileStatus.textContent='Failed to save profile.'; return; }
        if(profileStatus) profileStatus.textContent='Profile updated.';
        await bootstrapSession();
      });

      clearChatBtn?.addEventListener('click', async ()=>{
        if(modStatus) modStatus.textContent='Clearing chat...';
        const r = await fetch(API+'moderation/clear-chat', { method:'POST', credentials:'include', headers:{'X-WP-Nonce':restNonce} });
        if(!r.ok){ if(modStatus) modStatus.textContent='Clear chat failed.'; return; }
        await loadChat();
        if(modStatus) modStatus.textContent='Chat cleared.';
      });

      resetScoresBtn?.addEventListener('click', async ()=>{
        const game = (resetGameInput?.value||'').trim();
        if(modStatus) modStatus.textContent='Resetting scores...';
        const r = await fetch(API+'scores/reset', { method:'POST', credentials:'include', headers:{'content-type':'application/json','X-WP-Nonce':restNonce}, body: JSON.stringify({game}) });
        if(!r.ok){ if(modStatus) modStatus.textContent='Reset scores failed.'; return; }
        await loadLeaderboard();
        if(modStatus) modStatus.textContent = game ? ('Scores reset for '+game) : 'All scores reset.';
      });

      petFeedBtn?.addEventListener('click', ()=>petAction('feed'));
      petPlayBtn?.addEventListener('click', ()=>petAction('play'));
      petRestBtn?.addEventListener('click', ()=>petAction('rest'));
      petRenameBtn?.addEventListener('click', ()=>petAction('rename', { name:(petNameInput?.value||'').trim() }));
      petSkinSaveBtn?.addEventListener('click', ()=>petAction('setskin', { skin:(petSkinSelect?.value||'default') }));

      clearWallBtn?.addEventListener('click', async ()=>{
        if(modStatus) modStatus.textContent='Clearing wall...';
        const r = await fetch(API+'moderation/clear-wall', { method:'POST', credentials:'include', headers:{'X-WP-Nonce':restNonce} });
        if(!r.ok){ if(modStatus) modStatus.textContent='Clear wall failed.'; return; }
        await loadWall();
        if(modStatus) modStatus.textContent='Wall cleared.';
      });

      registerForm?.addEventListener('submit', async (e)=>{
        e.preventDefault();
        const fd = new FormData(registerForm);
        const payload = {
          username: String(fd.get('username')||'').trim(),
          email: String(fd.get('email')||'').trim(),
          password: String(fd.get('password')||''),
          age13: !!fd.get('age13')
        };
        if(registerStatus) registerStatus.textContent = 'Creating account...';
        const r = await fetch(API+'register', {
          method:'POST',
          credentials:'include',
          headers:{'content-type':'application/json'},
          body: JSON.stringify(payload)
        });
        const j = await r.json().catch(()=>({}));
        if(!r.ok){
          const map = {
            invalid_username:'Invalid username',
            invalid_email:'Invalid email',
            weak_password:'Password too short (min 8)',
            username_taken:'Username already taken',
            email_taken:'Email already used',
            rate_limited:'Please wait and try again'
          };
          if(registerStatus) registerStatus.textContent = 'Signup failed: ' + (map[j.error] || j.error || r.status);
          return;
        }
        if(registerStatus) registerStatus.textContent = 'Account created. Reloading...';
        setTimeout(()=>window.location.reload(), 600);
      });

gameMetaForm?.addEventListener('submit', async (e)=>{
        e.preventDefault();
        const fd = new FormData(gameMetaForm);
        const payload = {
          slug:String(fd.get('slug')||'').trim(),
          category:String(fd.get('category')||'').trim(),
          difficulty:String(fd.get('difficulty')||'').trim(),
          controls:String(fd.get('controls')||'').trim(),
          description:String(fd.get('description')||'').trim(),
        };
        if(gameMetaStatus) gameMetaStatus.textContent='Saving game metadata...';
        const r = await fetch(API+'games/meta',{method:'POST',credentials:'include',headers:{'content-type':'application/json','X-WP-Nonce':restNonce},body:JSON.stringify(payload)});
        if(!r.ok){ if(gameMetaStatus) gameMetaStatus.textContent='Failed to save metadata.'; return; }
        if(gameMetaStatus) gameMetaStatus.textContent='Game metadata saved.';
        loadGameMeta();
      });

      gameUploadForm?.addEventListener('submit', async (e)=>{
        e.preventDefault();
        const fd = new FormData(gameUploadForm);
        if(gameUploadStatus) gameUploadStatus.textContent = 'Uploading game...';
        const r = await fetch(API+'games', { method:'POST', credentials:'include', headers:{'X-WP-Nonce':restNonce}, body:fd });
        const j = await r.json().catch(()=>({}));
        if(!r.ok){
          if(gameUploadStatus) gameUploadStatus.textContent = 'Upload failed: ' + (j.error || r.status);
          return;
        }
        const checks = Array.isArray(j.checks)?j.checks:[];
        const qa = checks.length ? (' QA: '+checks.map(c=>`${c.name}:${c.ok?'ok':'warn'}`).join(', ')) : '';
        if(gameUploadStatus) gameUploadStatus.textContent = 'Game uploaded.'+qa+' Reloading...';
        const slug = j.slug ? String(j.slug) : '';
        setTimeout(()=>{ window.location.href = slug ? ('?game='+encodeURIComponent(slug)) : window.location.href; }, 500);
      });

      wallForm?.addEventListener('submit', async (e)=>{
        e.preventDefault();
        const fd=new FormData(wallForm);
        const res=await fetch(API+'pixel-wall',{method:'POST',body:fd});
        if(res.ok){ wallForm.reset(); loadWall(); }
      });

      bootstrapSession().then(()=>{ loadChat(); loadWall(); loadGameMeta(); loadLeaderboard(); loadPet(); });
      setInterval(async ()=>{ await bootstrapSession(); loadChat(); loadWall(); loadGameMeta(); loadLeaderboard(); loadPet(); }, 20000);
    })();
    </script>
    <?php
    return ob_get_clean();
});

add_action('wp_enqueue_scripts', function () {
    if (is_admin()) return;

    wp_enqueue_style('prismtek-pixel-font', 'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap', [], null);

    $css = <<<'CSS'
:root {
  --pv-bg-soft: #191a38;
  --pv-line: #7e85ff;
  --pv-accent: #7f65ff;
  --pv-accent-2: #59d9ff;
  --pv-text: #f2f4ff;
  --pv-muted: #b7bee9;
}

body.home,
body.page {
  color: var(--pv-text) !important;
  background: #0f1023 !important;
  font-family: "Press Start 2P", ui-monospace, Menlo, Consolas, monospace !important;
}

html, body {
  width: 100%;
  min-height: 100%;
  overflow-x: hidden;
  background: #0f1023 !important;
}

.entry-content p,
.entry-content li,
.entry-content a,
.ast-footer-copyright,
.pph-wrap, .pph-wrap * {
  font-family: "Press Start 2P", ui-monospace, Menlo, Consolas, monospace !important;
}

#pv-scene {
  position: fixed;
  top: -24vh;
  right: -24vw;
  bottom: -24vh;
  left: -24vw;
  z-index: 0;
  pointer-events: none;
  overflow: hidden;
}

#pv-scene .pv-canvas {
  width: 100%;
  height: 100%;
  display: block;
  image-rendering: pixelated;
  image-rendering: crisp-edges;
  transform-origin: 50% 55%;
  animation: pvZoomQuilt 45s linear infinite, pvDayCycle 140s linear infinite;
}

#pv-scene .pv-cloud-back { animation: pvCloudPulse 20s ease-in-out infinite; }
#pv-scene .pv-cloud-front { animation: pvCloudPulse 14s ease-in-out infinite; }
#pv-scene .pv-stars { animation: pvStarCycle 140s linear infinite; }
#pv-scene .pv-rain { animation: pvRainCycle 20s linear infinite; }
#pv-scene .pv-water-shimmer { animation: pvWater 5.6s steps(6, end) infinite; }
#pv-scene .pv-firefly { animation: pvFirefly 3.9s steps(4, end) infinite; }
#pv-scene .pv-firefly.f2 { animation-delay: .8s; }
#pv-scene .pv-firefly.f3 { animation-delay: 1.4s; }
#pv-scene .pv-firefly.f4 { animation-delay: 2s; }
#pv-scene .pv-firefly.f5 { animation-delay: 2.7s; }
#pv-scene .pv-bird { animation: pvBird 6.2s steps(2, end) infinite; }
#pv-scene .pv-rabbit { animation: pvHop 2.8s steps(3, end) infinite; }
#pv-scene .pv-deer { animation: pvGraze 5.4s steps(2, end) infinite; }

body.home::before,
body.page::before {
  content: "";
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 1;
  background: repeating-linear-gradient(
    to bottom,
    rgba(255,255,255,.03) 0,
    rgba(255,255,255,.03) 1px,
    transparent 1px,
    transparent 3px
  );
}

.site,
#page,
.site-content,
.ast-plain-container,
.ast-page-builder-template,
.ast-separate-container,
.ast-plain-container #content,
.ast-plain-container #content .ast-container,
.ast-plain-container #primary,
.ast-plain-container #main {
  background: transparent !important;
}

#page, #content, .site-content, .site-main, .entry-content, .ast-container, .site-primary-header-wrap, .site-below-footer-wrap {
  position: relative;
  z-index: 2;
}

.ast-main-header-wrap,
.ast-primary-header-bar,
.ast-mobile-header-wrap .ast-primary-header-bar {
  width: 100vw !important;
  max-width: 100vw !important;
  box-sizing: border-box !important;
  margin-left: 0 !important;
  margin-right: 0 !important;
  left: 50%;
  transform: translateX(-50%);
  position: relative;
  padding-left: 12px !important;
  padding-right: 12px !important;
  border-left: 0 !important;
  border-right: 0 !important;
}

.site-primary-header-wrap.ast-container,
.ast-builder-grid-row-container.site-header-focus-item.ast-container,
.ast-builder-grid-row-container .ast-builder-grid-row {
  width: 100% !important;
  max-width: 100% !important;
  margin: 0 auto !important;
  box-sizing: border-box !important;
}

.main-header-menu {
  display: flex !important;
  flex-wrap: wrap !important;
  row-gap: 6px !important;
}

.site-header,
.ast-primary-header-bar,
.ast-mobile-header-wrap .ast-primary-header-bar,
.ast-mobile-popup-inner,
.ast-separate-container .ast-article-single,
.ast-separate-container .ast-article-post,
.ast-separate-container .comments-area,
.ast-separate-container .ast-archive-description,
.ast-separate-container.ast-two-container #secondary .widget {
  background: rgba(25, 26, 56, .78) !important;
  backdrop-filter: blur(1.2px);
  border: 2px solid var(--pv-line) !important;
  border-radius: 0 !important;
  box-shadow: 6px 6px 0 rgba(61, 68, 138, .8) !important;
}

/* Prevent top nav shadow from overlapping page headings */
.site-header,
.ast-primary-header-bar,
.ast-mobile-header-wrap .ast-primary-header-bar {
  box-shadow: 0 3px 0 rgba(61, 68, 138, .75) !important;
  margin-bottom: 8px !important;
}

.site-content,
#content,
.ast-container {
  padding-top: 6px !important;
}

.site-title a,
.main-header-menu > .menu-item > .menu-link,
h1,h2,h3,h4,h5,h6,
.entry-title,
.wp-block-button__link,
button, .ast-button, .ast-custom-button, input[type="submit"] {
  font-family: "Press Start 2P", ui-monospace, Menlo, Consolas, monospace !important;
  letter-spacing: .02em;
}

.main-header-menu > .menu-item > .menu-link {
  text-transform: uppercase;
  font-size: .72rem !important;
  color: #dbe0ff !important;
  white-space: normal !important;
  line-height: 1.2 !important;
}

.entry-title, .entry-content h2, .entry-content h3 {
  color: #ffffff !important;
  text-shadow: 2px 2px 0 rgba(0,0,0,.75);
}

.entry-content, .entry-content p, .entry-content li, .entry-content span, .site-footer, .ast-footer-copyright {
  color: #ffffff !important;
  text-shadow: 1px 1px 0 #000 !important;
}

a, a:visited {
  color: #ffffff !important;
  text-shadow: 1px 1px 0 #000 !important;
  text-decoration: underline;
}
a:hover, a:focus { color: #ffffff !important; }

.entry-content ol {
  list-style-position: outside !important;
  padding-left: 1.8rem !important;
  margin-left: 0 !important;
}
.entry-content ol li {
  padding-left: .2rem !important;
}
@media (max-width: 768px) {
  .entry-content ol { padding-left: 1.4rem !important; }
}

.page-grid{display:grid;gap:14px;margin-top:10px}
.page-card{background:rgba(24,25,58,.88);border:2px solid var(--pv-line);box-shadow:6px 6px 0 rgba(61,68,138,.68);padding:14px}
.page-card h3{margin-top:0}
.page-links{display:flex;gap:8px;flex-wrap:wrap}
.page-pill{display:inline-block;padding:6px 10px;border:1px solid #4c5498;background:#11173b;color:#fff;text-decoration:none}
.page-grid{max-width:980px}
.page-card{border-width:2px;transition:transform .12s ease, box-shadow .12s ease}
.page-card:hover{transform:translateY(-1px);box-shadow:8px 8px 0 rgba(61,68,138,.62)}
.page-card p{line-height:1.6}.entry-content h2,.entry-content h3{margin-bottom:.45rem}.entry-content p{margin:.5rem 0 1rem}.page-links{margin-top:.45rem}
.pph-pet-view{padding:10px;border:1px solid #4c5498;background:#0f1130;font-size:12px;line-height:1.45;min-height:52px}


.wp-block-button__link,
button,
.ast-button,
.ast-custom-button,
input[type="submit"],
.menu-toggle {
  border: 2px solid #dfe3ff !important;
  border-radius: 0 !important;
  box-shadow: 4px 4px 0 rgba(55, 63, 125, .9) !important;
  text-transform: uppercase;
  background: linear-gradient(135deg, var(--pv-accent) 0%, var(--pv-accent-2) 100%) !important;
  color: #fff !important;
}

.wp-block-button__link:hover,
button:hover,
.ast-button:hover,
.ast-custom-button:hover,
input[type="submit"]:hover,
.menu-toggle:hover {
  transform: translate(-1px, -1px);
  box-shadow: 6px 6px 0 rgba(55, 63, 125, .95) !important;
}

@keyframes pvZoomQuilt {
  0% { transform: scale(1); }
  100% { transform: scale(1.55); }
}
@keyframes pvCloudPulse {
  0%,100% { opacity: .72; }
  50% { opacity: .9; }
}
@keyframes pvWater {
  0%,100% { opacity: .22; }
  40% { opacity: .62; }
  65% { opacity: .35; }
}
@keyframes pvDayCycle {
  0%, 22% { filter: brightness(1) saturate(1); }
  35% { filter: brightness(1.05) saturate(1.05); }
  52% { filter: brightness(.9) saturate(1.08) hue-rotate(-6deg); }
  68% { filter: brightness(.62) saturate(.9) hue-rotate(12deg); }
  82% { filter: brightness(.52) saturate(.84) hue-rotate(18deg); }
  100% { filter: brightness(1) saturate(1); }
}
@keyframes pvStarCycle {
  0%, 58%, 100% { opacity: 0; }
  70%, 84% { opacity: .65; }
}
@keyframes pvRainCycle {
  0%, 72%, 100% { opacity: 0; }
  78%, 90% { opacity: .36; }
}
@keyframes pvFirefly { 0%,100% { opacity:.18; } 45% { opacity:.82; } }
@keyframes pvBird { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-1px); } }
@keyframes pvHop { 0%,100% { transform: translateY(0); } 40% { transform: translateY(-2px); } }
@keyframes pvGraze { 0%,100% { transform: translateY(0); } 50% { transform: translateY(1px); } }

@media (max-width:900px) {
  #pv-scene .pv-firefly, #pv-scene .pv-animal, #pv-scene .pv-bird { display:none; }
}
@media (max-width:768px) {
  .main-header-menu > .menu-item > .menu-link { font-size: .58rem !important; }
  .ast-primary-header-bar,
  .ast-mobile-header-wrap .ast-primary-header-bar {
    padding-left: 8px !important;
    padding-right: 8px !important;
  }
}
CSS;

    wp_register_style('prismtek-pixel-vibes', false, [], null);
    wp_enqueue_style('prismtek-pixel-vibes');
    wp_add_inline_style('prismtek-pixel-vibes', $css);
}, 9999);

function prismtek_pixel_scene_markup_once() {
    static $printed = false;
    if ($printed || is_admin()) return;
    $printed = true;

    echo <<<'HTML'
<div id="pv-scene" aria-hidden="true">
  <svg class="pv-canvas" viewBox="0 0 320 180" preserveAspectRatio="xMidYMid slice" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="pvSky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#5f8fe0"/>
        <stop offset="35%" stop-color="#8dbbff"/>
        <stop offset="65%" stop-color="#c3deff"/>
        <stop offset="100%" stop-color="#d6ebff"/>
      </linearGradient>
      <linearGradient id="pvHillBack" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#6fae66"/>
        <stop offset="100%" stop-color="#4f8548"/>
      </linearGradient>
      <linearGradient id="pvHillFront" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#7fc56d"/>
        <stop offset="100%" stop-color="#456f40"/>
      </linearGradient>
    </defs>

    <rect x="0" y="0" width="320" height="180" fill="url(#pvSky)"/>

    <g class="pv-cloud-back" fill="#eef7ff" opacity=".48">
      <rect x="22" y="22" width="30" height="6"/><rect x="40" y="18" width="32" height="8"/><rect x="65" y="24" width="26" height="6"/>
      <rect x="152" y="27" width="24" height="6"/><rect x="168" y="23" width="30" height="8"/><rect x="194" y="29" width="22" height="6"/>
      <rect x="254" y="19" width="22" height="6"/><rect x="270" y="15" width="28" height="8"/><rect x="294" y="22" width="24" height="6"/>
    </g>

    <g class="pv-cloud-front" fill="#ffffff" opacity=".74">
      <rect x="10" y="40" width="34" height="8"/><rect x="28" y="36" width="38" height="10"/><rect x="56" y="42" width="30" height="8"/>
      <rect x="200" y="48" width="36" height="8"/><rect x="222" y="44" width="40" height="10"/><rect x="252" y="50" width="28" height="8"/>
    </g>

    <rect x="258" y="26" width="26" height="26" fill="#ffe79a" opacity=".45"/><rect x="262" y="30" width="18" height="18" fill="#ffd261"/>

    <polygon points="0,98 38,64 62,86 96,58 126,90 166,54 198,88 236,60 272,92 320,64 320,120 0,120" fill="#7892be"/>
    <polygon points="0,110 30,82 54,98 90,72 120,102 150,76 188,104 224,78 256,106 290,82 320,102 320,126 0,126" fill="#617da8"/>

    <path d="M0 132 C32 118, 58 122, 88 132 C118 142, 146 136, 176 128 C210 120, 238 122, 270 132 C292 139, 307 138, 320 132 L320 180 L0 180 Z" fill="url(#pvHillBack)"/>
    <path d="M0 146 C30 132, 58 134, 92 144 C124 154, 156 150, 186 142 C214 134, 246 136, 278 146 C298 152, 310 151, 320 147 L320 180 L0 180 Z" fill="url(#pvHillFront)"/>

    <g fill="#5a934f" opacity=".52"><rect x="0" y="150" width="320" height="1"/><rect x="0" y="156" width="320" height="1"/><rect x="0" y="162" width="320" height="1"/><rect x="0" y="168" width="320" height="1"/></g>

    <g>
      <polygon points="20,142 28,126 36,142" fill="#2b5d3a"/><rect x="27" y="142" width="2" height="6" fill="#3e2c20"/>
      <polygon points="48,140 58,118 68,140" fill="#2f6a40"/><rect x="57" y="140" width="2" height="6" fill="#3e2c20"/>
      <polygon points="84,142 92,128 100,142" fill="#2a5f3a"/><rect x="91" y="142" width="2" height="6" fill="#3e2c20"/>
      <polygon points="118,145 129,121 140,145" fill="#2f6b40"/><rect x="128" y="145" width="2" height="6" fill="#3e2c20"/>
      <polygon points="154,144 164,123 174,144" fill="#2c643d"/><rect x="163" y="144" width="2" height="6" fill="#3e2c20"/>
      <polygon points="194,142 203,125 212,142" fill="#2a603a"/><rect x="202" y="142" width="2" height="6" fill="#3e2c20"/>
      <polygon points="226,145 237,122 248,145" fill="#2e6a40"/><rect x="236" y="145" width="2" height="6" fill="#3e2c20"/>
      <polygon points="266,143 275,126 284,143" fill="#295d38"/><rect x="274" y="143" width="2" height="6" fill="#3e2c20"/>
      <polygon points="292,144 302,124 312,144" fill="#2d653d"/><rect x="301" y="144" width="2" height="6" fill="#3e2c20"/>
    </g>

    <g>
      <rect x="12" y="154" width="2" height="2" fill="#ffb5cf"/><rect x="36" y="160" width="2" height="2" fill="#ffe58a"/><rect x="68" y="152" width="2" height="2" fill="#9df2ff"/>
      <rect x="96" y="166" width="2" height="2" fill="#ffc4de"/><rect x="124" y="156" width="2" height="2" fill="#ffe58a"/><rect x="162" y="162" width="2" height="2" fill="#9df2ff"/>
      <rect x="194" y="154" width="2" height="2" fill="#ffb5cf"/><rect x="228" y="166" width="2" height="2" fill="#ffe58a"/><rect x="256" y="156" width="2" height="2" fill="#9df2ff"/><rect x="292" y="160" width="2" height="2" fill="#ffc4de"/>
    </g>

    <g class="pv-animal pv-rabbit" fill="#f7efe4"><rect x="90" y="158" width="4" height="3"/><rect x="91" y="156" width="1" height="2"/><rect x="93" y="156" width="1" height="2"/><rect x="94" y="159" width="1" height="1" fill="#d9c9b9"/></g>
    <g class="pv-animal pv-rabbit" fill="#efe8de"><rect x="206" y="164" width="4" height="3"/><rect x="207" y="162" width="1" height="2"/><rect x="209" y="162" width="1" height="2"/></g>
    <g class="pv-animal pv-deer" fill="#9e6b45"><rect x="144" y="158" width="7" height="3"/><rect x="151" y="157" width="2" height="2"/><rect x="145" y="161" width="1" height="3"/><rect x="149" y="161" width="1" height="3"/><rect x="152" y="158" width="1" height="1" fill="#e6d8c6"/></g>

    <g class="pv-bird" fill="#1c2d3e" opacity=".8"><rect x="120" y="56" width="2" height="1"/><rect x="123" y="56" width="2" height="1"/><rect x="124" y="55" width="1" height="1"/></g>
    <g class="pv-bird" fill="#203245" opacity=".8"><rect x="212" y="52" width="2" height="1"/><rect x="215" y="52" width="2" height="1"/><rect x="216" y="51" width="1" height="1"/></g>

    <g class="pv-stars" fill="#f3f7ff" opacity="0">
      <rect x="24" y="18" width="1" height="1"/><rect x="48" y="12" width="1" height="1"/><rect x="92" y="20" width="1" height="1"/>
      <rect x="134" y="14" width="1" height="1"/><rect x="176" y="22" width="1" height="1"/><rect x="218" y="10" width="1" height="1"/>
      <rect x="246" y="18" width="1" height="1"/><rect x="278" y="12" width="1" height="1"/><rect x="306" y="20" width="1" height="1"/>
    </g>

    <g class="pv-rain" stroke="#cfe6ff" stroke-width="1" opacity="0">
      <line x1="24" y1="80" x2="22" y2="86"/><line x1="52" y1="84" x2="50" y2="90"/><line x1="80" y1="76" x2="78" y2="82"/>
      <line x1="108" y1="82" x2="106" y2="88"/><line x1="136" y1="78" x2="134" y2="84"/><line x1="164" y1="86" x2="162" y2="92"/>
      <line x1="192" y1="80" x2="190" y2="86"/><line x1="220" y1="84" x2="218" y2="90"/><line x1="248" y1="78" x2="246" y2="84"/>
      <line x1="276" y1="86" x2="274" y2="92"/><line x1="304" y1="80" x2="302" y2="86"/>
    </g>

    <g fill="#fff4b4"><rect class="pv-firefly f1" x="56" y="138" width="2" height="2"/><rect class="pv-firefly f2" x="104" y="134" width="2" height="2"/><rect class="pv-firefly f3" x="170" y="140" width="2" height="2"/><rect class="pv-firefly f4" x="236" y="136" width="2" height="2"/><rect class="pv-firefly f5" x="282" y="132" width="2" height="2"/></g>
  </svg>
</div>
HTML;
}

add_action('wp_body_open', 'prismtek_pixel_scene_markup_once', 1);
add_action('wp_footer', 'prismtek_pixel_scene_markup_once', 1);


add_filter('show_admin_bar', '__return_false');


function prismtek_pixel_find_latest_iso_url() {
    $repos = ['codysumpter-cloud/PrismBot-Public', 'codysumpter-cloud/omni-bmo'];
    foreach ($repos as $repo) {
        $api = 'https://api.github.com/repos/' . $repo . '/releases';
        $res = wp_remote_get($api, [
            'timeout' => 10,
            'headers' => [
                'User-Agent' => 'prismtek-dev-site',
                'Accept' => 'application/vnd.github+json',
            ],
        ]);

    


        if (is_wp_error($res)) continue;
        $body = wp_remote_retrieve_body($res);
        $rows = json_decode($body, true);
        if (!is_array($rows)) continue;
        foreach ($rows as $rel) {
            $assets = is_array($rel['assets'] ?? null) ? $rel['assets'] : [];
            foreach ($assets as $a) {
                $name = strtolower((string) ($a['name'] ?? ''));
                if (str_ends_with($name, '.iso')) {
                    $u = (string) ($a['browser_download_url'] ?? '');
                    if ($u) return $u;
                }
            }
        }
    }
    return 'https://github.com/codysumpter-cloud/PrismBot-Public/releases';
}

add_action('template_redirect', function () {
    if (!isset($_GET['prismtek_iso_dl'])) return;
    $url = prismtek_pixel_find_latest_iso_url();
    wp_redirect($url, 302);
    exit;
});

add_action('init', function () {
    if (get_option('users_can_register') != '1') update_option('users_can_register', '1');
    if (!get_option('default_role')) update_option('default_role', 'subscriber');
});

add_filter('login_redirect', function ($redirect_to, $requested, $user) {
    if (!is_wp_error($user) && $user) return home_url('/pixel-arcade/');
    return $redirect_to;
}, 10, 3);


add_filter('auth_cookie_expiration', function ($length, $user_id, $remember) {
    // Keep users signed in by default until they explicitly log out.
    return 60 * DAY_IN_SECONDS;
}, 99, 3);


function prismtek_pixel_nocache() {
    if (is_admin()) return;
    if (function_exists('is_page') && is_page('pixel-arcade')) {
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        nocache_headers();
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    }
}
add_action('template_redirect', 'prismtek_pixel_nocache', 0);

// ===== MISSING SHORTCODES - ADDED TO RESTORE FUNCTIONALITY =====

// Studio-only page shortcode (used on /pixel-studio/)
add_shortcode('prism_studio_pro_page', function() {
    $can_moderate = current_user_can('manage_options');
    $viewer_logged_in = is_user_logged_in();
    $viewer_id = get_current_user_id();
    $viewer_nonce = $viewer_logged_in ? wp_create_nonce('wp_rest') : '';
    
    ob_start();
    ?>
    <section class="pph-wrap">
        <h2>Pixel Studio Pro</h2>
        <p>Import, draw, edit, download, and post to Memory Wall.</p>
        <p><a href="/community-center/">Community Center</a> · <a href="/arcade-games/">Arcade Games</a></p>
        
        <article class="pph-card">
            <details class="pph-toggle" data-toggle-key="studio" open>
                <summary>Pixel Studio</summary>
                <div class="pph-studio-wrap">
                    <div class="pph-canvas-shell">
                        <canvas id="pph-studio-canvas" width="512" height="512" aria-label="Pixel drawing canvas"></canvas>
                        <canvas id="pph-grid-canvas" width="512" height="512" aria-hidden="true"></canvas>
                    </div>
                    <div class="pph-studio-tools">
                        <label>Tool
                            <select id="pph-tool">
                                <option value="pen" selected>Pen</option>
                                <option value="line">Line</option>
                                <option value="rect">Rectangle</option>
                                <option value="circle">Circle</option>
                                <option value="bucket">Paint Bucket</option>
                                <option value="wand">Magic Wand</option>
                                <option value="lasso">Lasso (rect)</option>
                                <option value="eraser">Eraser</option>
                                <option value="eyedropper">Eyedropper</option>
                            </select>
                        </label>
                        <div class="pph-tool-row">
                            <label>Color <input type="color" id="pph-color" value="#59d9ff" /></label>
                            <label>Brush
                                <select id="pph-brush">
                                    <option value="1">1px</option>
                                    <option value="2">2px</option>
                                    <option value="3" selected>3px</option>
                                    <option value="4">4px</option>
                                    <option value="6">6px</option>
                                </select>
                            </label>
                        </div>
                        <div class="pph-tool-row">
                            <label>Grid
                                <select id="pph-grid-size">
                                    <option value="32">32x32</option>
                                    <option value="48">48x48</option>
                                    <option value="64" selected>64x64</option>
                                    <option value="96">96x96</option>
                                    <option value="128">128x128</option>
                                </select>
                            </label>
                            <label>Tolerance <input type="range" id="pph-tolerance" min="0" max="96" value="24" /></label>
                            <label><input type="checkbox" id="pph-grid-toggle" checked /> Show Grid</label>
                        </div>
                        <div class="pph-tool-row">
                            <button type="button" id="pph-undo">Undo</button>
                            <button type="button" id="pph-redo">Redo</button>
                            <button type="button" id="pph-clear">Clear</button>
                        </div>
                        <div class="pph-tool-row">
                            <input id="pph-import-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif" />
                            <button type="button" id="pph-import">Import Image</button>
                            <button type="button" id="pph-strip-grid">Remove Grid Lines</button>
                        </div>
                        <button type="button" id="pph-download">Download PNG</button>
                        <button type="button" id="pph-post-wall">Publish to Memory Wall</button>
                    </div>
                </div>
            </details>
        </article>
    </section>
    <style>
        .pph-studio-wrap{display:grid;grid-template-columns:minmax(0,520px) minmax(0,1fr);gap:12px;align-items:start;min-width:0}
        .pph-canvas-shell{position:relative;width:100%;max-width:520px;aspect-ratio:1/1}
        #pph-studio-canvas,#pph-grid-canvas{position:absolute;inset:0;width:100%;height:100%;border:2px solid #6b74c7;background:#0e1026;image-rendering:pixelated;cursor:crosshair;display:block}
        #pph-grid-canvas{pointer-events:none;background:transparent}
        .pph-studio-tools{display:grid;gap:8px;min-width:0}
        .pph-tool-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;min-width:0}
        .pph-studio-tools label{display:grid;gap:4px;font-size:12px;color:#fff;text-shadow:1px 1px 0 #000}
        .pph-studio-tools select,.pph-studio-tools input[type="color"],.pph-studio-tools input[type="range"],.pph-studio-tools input[type="file"],.pph-studio-tools button{padding:8px;border:1px solid #40488a;background:#101330;color:#eef1ff;min-width:0}
        .pph-studio-tools button{cursor:pointer}
        @media (max-width:1100px){.pph-studio-wrap{grid-template-columns:1fr}}
    </style>
    <?php
    return ob_get_clean();
});

// Creatures portal shortcode (used on /prism-creatures/)
add_shortcode('prism_creatures_portal', function() {
    $viewer_logged_in = is_user_logged_in();
    $viewer_id = get_current_user_id();
    
    ob_start();
    ?>
    <section class="pph-wrap">
        <h2>Prism Creatures</h2>
        <p>Adopt, care for, and customize your pixel companion.</p>
        
        <?php if (!$viewer_logged_in): ?>
        <p><a href="<?php echo esc_url(wp_login_url(home_url('/prism-creatures/'))); ?>">Login</a> to adopt a creature!</p>
        <?php endif; ?>
        
        <?php if ($viewer_logged_in): ?>
        <article class="pph-card">
            <details class="pph-toggle" data-toggle-key="pet" open>
                <summary>My Pixel Creature</summary>
                <div id="pph-pet-view" class="pph-pet-view">Loading creature...</div>
                <div class="pph-tool-row">
                    <button type="button" id="pph-pet-feed">Feed</button>
                    <button type="button" id="pph-pet-play">Play</button>
                    <button type="button" id="pph-pet-rest">Rest</button>
                </div>
                <div class="pph-tool-row">
                    <input id="pph-pet-name" type="text" maxlength="20" placeholder="Rename creature" />
                    <button type="button" id="pph-pet-rename">Save Name</button>
                </div>
                <div class="pph-tool-row">
                    <select id="pph-pet-skin"><option value="default">default</option></select>
                    <button type="button" id="pph-pet-skin-save">Apply Skin</button>
                </div>
                <p id="pph-pet-status" class="pph-status"></p>
            </details>
        </article>
        <?php endif; ?>
        
        <h3>Community Creatures</h3>
        <?php echo do_shortcode('[prism_pet_showcase]'); ?>
    </section>
    <style>
        .pph-tool-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;min-width:0}
        .pph-tool-row button,.pph-tool-row select,.pph-tool-row input{padding:8px;border:1px solid #40488a;background:#101330;color:#eef1ff}
        .pph-status{display:block;margin-top:8px;font-size:11px;color:#ffe08a;text-shadow:1px 1px 0 #000}
    </style>
    <?php
    return ob_get_clean();
});
