Replace your wp-content/mu-plugins/prismtek-pixel-vibes.php with prismtek-pixel-vibes.php
Then refresh your site.